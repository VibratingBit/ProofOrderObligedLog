@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0" || exit /b 1
if /I "%~1"=="cleanup" goto cleanup
powershell.exe -NoProfile -ExecutionPolicy Bypass ^
    -File "%~dp0scripts\build.ps1" ^
    -NetRoot "%~dp0..\Net"
set "BUILD_RESULT=%errorlevel%"
if not "%BUILD_RESULT%"=="0" (
    echo [ERROR] Build failed. The previous server EXE has NOT been updated.
    pause
    exit /b %BUILD_RESULT%
)
echo The server is started separately from the EXE in Launch.
pause
exit /b %BUILD_RESULT%

:cleanup
powershell.exe -NoProfile -ExecutionPolicy Bypass ^
    -File "%~dp0scripts\build.ps1" ^
    -NetRoot "%~dp0..\Net" -CleanupOnly
set "BUILD_RESULT=%errorlevel%"
pause
exit /b %BUILD_RESULT%
