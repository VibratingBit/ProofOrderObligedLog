#ifndef LOG_PORTS_POLICY_H
#define LOG_PORTS_POLICY_H
int log_ports_classify(
    int result, const char *client, const char *internal,
    const char *description, const char *local, const char *port
);
#endif
