#ifndef LOG_TERMINAL_H
#define LOG_TERMINAL_H

#include <stdbool.h>
#include <stddef.h>

void log_terminal_init(void);
void log_terminal_close(void);
bool log_terminal_read(char *command, size_t capacity);
void log_terminal_wipe(void);

#endif
