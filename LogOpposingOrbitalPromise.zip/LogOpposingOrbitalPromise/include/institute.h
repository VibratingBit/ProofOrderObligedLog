#ifndef LOG_INSTITUTE_H
#define LOG_INSTITUTE_H
#include "entry.h"
bool log_institute_init(void);
bool log_institute_admin_exists(void);
void log_institute_set_https_ready(bool ready);
bool log_institute_https_ready(void);
bool log_institute_handle(const log_request *request, log_response *response);
int log_institute_role(const log_request *request, bool mutation);
#endif
