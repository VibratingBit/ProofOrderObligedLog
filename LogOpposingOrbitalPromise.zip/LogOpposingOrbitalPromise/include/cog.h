#ifndef LOG_COG_H
#define LOG_COG_H
#include <stdbool.h>
#include <stddef.h>
/* COG 1 text grammar: TABLE identifier, ROW hex(key) hex(UTF-8 value).
   No evaluation. Keys unique; values are app-schema data. Only trusted paths. */
int log_cog_get(const char *path,const char *table,const char *key,
    char *value,size_t capacity);
int log_cog_put(const char *path,const char *table,const char *key,
    const char *value,bool insert_only);
int log_cog_remove(const char *path,const char *table,const char *key);
typedef int (*log_cog_visitor)(const char *,const char *,void *);
int log_cog_scan(const char *path,const char *table,
    log_cog_visitor visitor,void *context);
#endif
