#ifndef LOG_LOGGING_H
#define LOG_LOGGING_H

#include <stdbool.h>

void log_write(const char *category, const char *format, ...);
void log_access_enabled(bool enabled);
bool log_access_is_enabled(void);

#endif
