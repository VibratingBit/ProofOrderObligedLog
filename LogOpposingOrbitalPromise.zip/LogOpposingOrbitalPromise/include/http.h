#ifndef LOG_HTTP_H
#define LOG_HTTP_H

#include "entry.h"
#include <stddef.h>

/* Returns zero on success or an HTTP status for an invalid request. */
int log_http_parse(
    char *data,
    size_t length,
    log_request *request
);

const char *log_http_reason(int status);

#endif
