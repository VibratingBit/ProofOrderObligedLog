#ifndef LOG_MAIL_H
#define LOG_MAIL_H
#include "entry.h"
#include "pool.h"
#define LOG_MAIL_INDEX "Mail/Sshhm/mailbox.cog"
bool log_mail_init(void);
void log_mail_configure(const log_pool_config *config);
bool log_mail_handle(const log_request *request, log_response *response);
bool log_mail_commit(const char *id, size_t size, const char *from,
    const char *to, const char *path);
bool log_mail_deliver(const char *from, const char *to, const char *message,
    size_t length, char id[33]);
bool log_mail_address(const char *address);
bool log_mail_transport(const char *hostname, const char *from,
    const char *to, const char *message, char *error, size_t capacity);
#endif
