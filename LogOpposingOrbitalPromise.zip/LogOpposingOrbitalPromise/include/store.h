#ifndef LOG_STORE_H
#define LOG_STORE_H
#include <stdbool.h>
bool log_store_prepare(void);
int log_store_replace(const char *source, const char *destination);
#endif
