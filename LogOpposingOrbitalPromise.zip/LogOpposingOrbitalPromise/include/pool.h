#ifndef LOG_POOL_H
#define LOG_POOL_H

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    char hostname[256];
    char domains[16][256];
    unsigned domain_count;
    char site_title[256];
    char site_tagline[256];
    char http_bind[46];
    uint16_t http_port;
    char web_root[512];
    char log_file[512];
    char data_root[512];
    char https_bind[46];
    uint16_t https_port;
    char https_certificate[512];
    char https_private_key[512];
    unsigned max_connections;
    unsigned idle_timeout;
    unsigned max_per_ip;
    unsigned conn_rate_per_min;
    unsigned session_timeout;
    unsigned firewall_enabled;
    unsigned smtp_enabled;
    char smtp_bind[46];
    uint16_t smtp_port;
    char smtp_spool[512];
    unsigned smtp_max_size;
    unsigned dns_enabled;
    char dns_bind[46];
    uint16_t dns_port;
    unsigned upnp_legacy_compat;
    unsigned upnp_allow_permanent;
    unsigned upnp_enabled;
    unsigned upnp_lease;
} log_pool_config;

/* Return zero on success, otherwise write line-numbered diagnostics. */
int log_pool_load(
    const char *filename,
    log_pool_config *output,
    char *error,
    size_t capacity
);

#endif
