#ifndef LOG_SMTP_POLICY_H
#define LOG_SMTP_POLICY_H
#include "pool.h"
bool log_smtp_address(const char *command,char *output,size_t capacity);
bool log_smtp_recipient(const log_pool_config *config,const char *text);
#endif
