#ifndef LOG_ASSETS_H
#define LOG_ASSETS_H
#include "entry.h"
#include "pool.h"
void log_assets_configure(const log_pool_config *config);
void log_asset_response(const log_request *request, log_response *response);
void log_assets_free(void);
#endif
