#ifndef LOG_DNS_H
#define LOG_DNS_H
#include "pool.h"
bool log_dns_start(const log_pool_config *config);
void log_dns_stop(void);
#endif
