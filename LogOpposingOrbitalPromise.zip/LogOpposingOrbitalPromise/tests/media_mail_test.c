#include "mail.h"
#include "media.h"
#include "cog.h"
#include "store.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#endif
/* Isolate route/storage behavior; real session and CSRF checks have their own suite. */
bool log_institute_admin_exists(void) { return true; }
int log_institute_role(const log_request *request, bool mutation) {
    if (!request->secure || strcmp(request->cookie,"owner")) return 0;
    if (mutation && strcmp(request->csrf,"valid")) return 0;
    return 3;
}
bool log_mail_transport(const char *host, const char *from, const char *to,
    const char *message, char *error, size_t capacity) {
    (void)host; (void)from; (void)to; (void)message;
    snprintf(error,capacity,"Simulated destination unavailable");
    return false;
}
static log_request request;
static log_response response;
static void call(const char *method, const char *query, const char *body) {
    memset(&response,0,sizeof(response));
    strcpy(request.path,"/api/mail");
    snprintf(request.method,sizeof(request.method),"%s",method);
    snprintf(request.query,sizeof(request.query),"%s",query);
    request.body=body; request.body_length=strlen(body);
    assert(log_mail_handle(&request,&response));
}
static int clean(const char *key,const char *value,void *context) {
    (void)key;(void)context;
    const char *path=strrchr(value,'\t');
    if(path) remove(path+1);
    return 0;
}
int main(void) {
    assert(log_mail_init());
    log_cog_scan(LOG_MAIL_INDEX,"messages",clean,NULL);
    remove(LOG_MAIL_INDEX);remove("Mail/Sshhm/blocked.cog");
    log_pool_config config={0};
    strcpy(config.hostname,"example.test");config.smtp_enabled=1;
    log_mail_configure(&config);
    request.secure=true;
    call("GET","folder=inbox","");assert(response.status==403);
    strcpy(request.cookie,"owner");strcpy(request.csrf,"valid");
    call("GET","","");assert(response.status==200&&!strcmp(response.body,"[]"));
    const char *old_id="00000000000000000000000000000000";
    FILE *legacy=fopen("private/mail/00000000000000000000000000000000.eml","wb");assert(legacy);
    fputs("Subject: Legacy\r\n\r\nPreserved.\r\n",legacy);fclose(legacy);
    assert(!log_cog_put("private/mail/messages.cog","messages",old_id,
        "33\tsender@example.test\tSshhm@example.test\tprivate/mail/00000000000000000000000000000000.eml",true));
    assert(!log_cog_put("Mail/Sshhm/delivery.cog","delivery",old_id,"Sending…",true));
    assert(log_mail_init());
    char recovered[256];
    assert(!log_cog_get("Mail/Sshhm/delivery.cog","delivery",old_id,recovered,sizeof(recovered)));
    assert(strstr(recovered,"Interrupted"));
    assert(log_cog_get("private/mail/messages.cog","messages",old_id,recovered,sizeof(recovered))==1);
    call("GET","folder=inbox","");assert(strstr(response.body,"Legacy"));
    call("POST","","action=delete&id=00000000000000000000000000000000");assert(response.status==200);
    remove("private/mail/messages.cog");remove("Mail/Sshhm/delivery.cog");
    const char *source="From: sender@example.test\r\nSubject: A useful message\r\n\r\nHello. Caf\xe9.\r\n";
    char id[33];
    assert(log_mail_deliver("sender@example.test","Sshhm@example.test",source,strlen(source),id));
    call("GET","folder=inbox","");assert(response.status==200);
    assert(strstr(response.body,"A useful message"));
    assert(strstr(response.body,"\"delivery\":\"\"}"));
    char query[64];snprintf(query,sizeof(query),"id=%s",id);
    call("GET",query,"");assert(response.status==200&&strstr(response.body,"Hello.")&&strstr(response.body,"\\u00e9"));
    call("POST","","action=block&address=sender%40example.test");assert(response.status==200);
    char blocked_id[33];
    assert(log_mail_deliver("sender@example.test","Sshhm@example.test",source,strlen(source),blocked_id));
    call("GET","folder=blocked","");assert(response.status==200&&strstr(response.body,blocked_id));
    char body[100];snprintf(body,sizeof(body),"action=move&id=%s&folder=archive",id);
    call("POST","",body);assert(response.status==200);
    call("GET","folder=archive","");assert(strstr(response.body,id));
    request.csrf[0]=0;call("POST","",body);assert(response.status==403);
    strcpy(request.csrf,"valid");
    call("POST","","action=send&from=Sshhm%40example.test&to=Sshhm%40example.test&subject=Local&text=Test+message");
#if !defined(LOG_TEST_WITH_SMTP) || LOG_TEST_WITH_SMTP
    assert(response.status==200&&strstr(response.body,"\"accepted\":true"));
    call("GET","folder=sent","");assert(strstr(response.body,"Local"));
#else
    assert(response.status==503);
#endif
    assert(!log_mail_address("other@example.test\r\nBcc:x"));
    call("POST","","action=move&id=../../secret&folder=archive");assert(response.status==400);
#ifdef _WIN32
    _mkdir("Media");
#else
    mkdir("Media",0700);
#endif
    FILE *file=fopen("Media/sample.png","wb");assert(file);
    assert(fwrite("0123456789",1,10,file)==10);fclose(file);
    file=fopen("Media/secret.html","wb");assert(file);fputs("private",file);fclose(file);
    strcpy(request.method,"GET");strcpy(request.path,"/api/media");request.query[0]=0;
    assert(log_media_handle(&request,&response));assert(response.status==200);
    assert(strstr(response.body,"sample.png")&&!strstr(response.body,"secret.html"));
    strcpy(request.path,"/Media/file");strcpy(request.query,"name=sample.png");
    strcpy(request.range,"bytes=2-5");
    assert(log_media_handle(&request,&response));assert(response.status==206);
    assert(response.body_length==4&&!memcmp(response.body,"2345",4));
    strcpy(request.range,"bytes=-3");
    assert(log_media_handle(&request,&response));assert(response.body_length==3&&!memcmp(response.body,"789",3));
    strcpy(request.range,"bytes=5-");
    assert(log_media_handle(&request,&response));assert(response.status==206&&response.body_length==5);
    strcpy(request.range,"bytes=2junk");
    assert(log_media_handle(&request,&response));assert(response.status==416);
    request.range[0]=0;strcpy(request.query,"name=..%2Fprivate%2Fmembers.cog");
    assert(log_media_handle(&request,&response));assert(response.status==404);
    strcpy(request.path,"/Media/");assert(!log_media_handle(&request,&response));
    log_media_free();remove("Media/sample.png");remove("Media/secret.html");
    log_cog_scan(LOG_MAIL_INDEX,"messages",clean,NULL);
    remove(LOG_MAIL_INDEX);remove("Mail/Sshhm/blocked.cog");
    puts("Media/ranges/mailbox/folders/blocking/access tests passed");
    return 0;
}
