#include "tls.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>
#include <openssl/err.h>
#ifdef _WIN32
#include <direct.h>
#define make_directory(path) _mkdir(path)
#define change_directory(path) _chdir(path)
#else
#include <sys/stat.h>
#include <unistd.h>
#define make_directory(path) mkdir(path,0700)
#define change_directory(path) chdir(path)
#endif

static EVP_PKEY *generate_key(void) {
    EVP_PKEY_CTX *context = EVP_PKEY_CTX_new_from_name(NULL, "RSA", NULL);
    EVP_PKEY *key = NULL;
    assert(context != NULL);
    assert(EVP_PKEY_keygen_init(context) == 1);
    assert(EVP_PKEY_CTX_set_rsa_keygen_bits(context, 2048) == 1);
    assert(EVP_PKEY_generate(context, &key) == 1);
    EVP_PKEY_CTX_free(context);
    return key;
}

static void write_key(const char *path, EVP_PKEY *key) {
    FILE *file = fopen(path, "wb");
    assert(file != NULL);
    assert(PEM_write_PrivateKey(file, key, NULL, NULL, 0, NULL, NULL) == 1);
    assert(fclose(file) == 0);
}

static void write_certificate(const char *path, X509 *certificate) {
    FILE *file = fopen(path,"wb");
    assert(file);
    assert(PEM_write_X509(file,certificate)==1);
    assert(fclose(file)==0);
}

static void test_ssl_layout(X509 *certificate, EVP_PKEY *key, EVP_PKEY *other) {
    make_directory("tls-layout");
    make_directory("tls-layout/ssl");
    make_directory("tls-layout/Launch");
    write_certificate("tls-layout/ssl/LoveVessel-chain.pem",certificate);
    write_key("tls-layout/ssl/LoveVessel-key.pem",key);
    write_certificate("tls-layout/LoveShip-chain.pem",certificate);
    write_key("tls-layout/LoveShip-key.pem",key);
    assert(change_directory("tls-layout/Launch")==0);
    SSL_CTX *ship = log_tls_context("/ssl/LoveShip-chain.pem","/ssl/LoveShip-key.pem");
    assert(ship);
    SSL_CTX_free(ship);
    remove("ssl/LoveVessel-chain.pem");
    remove("ssl/LoveVessel-key.pem");
    const char *chain = "/ssl/LoveVessel-chain.pem";
    const char *private_key = "/ssl/LoveVessel-key.pem";
    SSL_CTX *context = log_tls_context(chain,private_key);
    assert(context);
    SSL_CTX_free(context);
    make_directory("ssl");
    write_certificate("ssl/LoveVessel-chain.pem",certificate);
    /* A partial Launch pair must not be mixed with a parent-folder key. */
    assert(log_tls_context(chain,private_key)==NULL);
    write_key("ssl/LoveVessel-key.pem",other);
    assert(log_tls_context(chain,private_key)==NULL);
    write_key("ssl/LoveVessel-key.pem",key);
    ERR_raise(ERR_LIB_USER,42);
    context = log_tls_context(chain,private_key);
    assert(context && ERR_peek_error()==0);
    SSL_CTX_free(context);
    FILE *file = fopen("ssl/LoveVessel-key.pem","wb");
    assert(file);
    const unsigned char password[] = "test-only-unlock-password";
    assert(PEM_write_PrivateKey(file,key,EVP_aes_256_cbc(),password,
        (int)sizeof(password)-1,NULL,NULL)==1);
    assert(fclose(file)==0);
    assert(log_tls_context(chain,private_key)==NULL);
    remove("ssl/LoveVessel-chain.pem");
    remove("ssl/LoveVessel-key.pem");
    assert(change_directory("../..")==0);
    remove("tls-layout/ssl/LoveVessel-chain.pem");
    remove("tls-layout/ssl/LoveVessel-key.pem");
    remove("tls-layout/LoveShip-chain.pem");
    remove("tls-layout/LoveShip-key.pem");
}

int main(void) {
    char resolved[256];
    assert(log_tls_resolve_path("/ssl/LoveVessel-chain.pem", resolved,
        sizeof(resolved)) == 0);
    assert(!strcmp(resolved, "./ssl/LoveVessel-chain.pem"));
    assert(log_tls_resolve_path("C:/certs/key.pem", resolved,
        sizeof(resolved)) == 0);
    assert(!strcmp(resolved, "C:/certs/key.pem"));
    assert(log_tls_resolve_path("/ssl/key.pem", resolved, 2) != 0);
    const char *certificate_path = "tls-test-cert.pem";
    const char *key_path = "tls-test-key.pem";
    const char *other_path = "tls-test-other-key.pem";
    EVP_PKEY *key = generate_key();
    EVP_PKEY *other_key = generate_key();
    X509 *certificate = X509_new();
    assert(certificate != NULL);
    assert(X509_set_version(certificate, 2) == 1);
    assert(ASN1_INTEGER_set(X509_get_serialNumber(certificate), 1) == 1);
    assert(X509_gmtime_adj(X509_getm_notBefore(certificate), -60) != NULL);
    assert(X509_gmtime_adj(X509_getm_notAfter(certificate), 3600) != NULL);
    assert(X509_set_pubkey(certificate, key) == 1);
    X509_NAME *name = X509_get_subject_name(certificate);
    assert(X509_NAME_add_entry_by_txt(
        name, "CN", MBSTRING_ASC,
        (const unsigned char *)"localhost", -1, -1, 0
    ) == 1);
    assert(X509_set_issuer_name(certificate, name) == 1);
    assert(X509_sign(certificate, key, EVP_sha256()) > 0);
    FILE *file = fopen(certificate_path, "wb");
    assert(file != NULL);
    assert(PEM_write_X509(file, certificate) == 1);
    assert(fclose(file) == 0);
    write_key(key_path, key);
    write_key(other_path, other_key);

    SSL_CTX *context = log_tls_context(certificate_path, key_path);
    assert(context != NULL);
    assert(SSL_CTX_get_min_proto_version(context) == TLS1_2_VERSION);
    SSL_CTX_free(context);
    assert(log_tls_context(certificate_path, other_path) == NULL);
    assert(log_tls_context("missing-test-certificate.pem", key_path) == NULL);

    test_ssl_layout(certificate,key,other_key);
    X509_free(certificate);
    EVP_PKEY_free(key);
    EVP_PKEY_free(other_key);
    remove(certificate_path);
    remove(key_path);
    remove(other_path);
    puts("TLS context/certificate/key tests passed");
    return 0;
}
