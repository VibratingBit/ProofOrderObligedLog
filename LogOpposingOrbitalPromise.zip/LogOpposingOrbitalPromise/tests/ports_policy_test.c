#include "ports_policy.h"
#include <assert.h>
int main(void) {
    assert(log_ports_classify(714, "", "", "", "10.0.0.2", "80") == 0);
    assert(log_ports_classify(501, "", "", "", "10.0.0.2", "80") == -3);
    assert(log_ports_classify(0, "10.0.0.2", "80", "OS66",
        "10.0.0.2", "80") == 2);
    assert(log_ports_classify(0, "10.0.0.3", "80", "OS66",
        "10.0.0.2", "80") == -1);
    assert(log_ports_classify(0, "10.0.0.2", "81", "OS66",
        "10.0.0.2", "80") == -1);
    assert(log_ports_classify(0, "10.0.0.2", "80", "PoolingArcSendSecret",
        "10.0.0.2", "80") == 1);
    return 0;
}
