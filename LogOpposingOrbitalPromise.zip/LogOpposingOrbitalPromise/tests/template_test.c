#include "template.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    log_template_value values[] = {{"name", "<script>&\"'"}};
    char *output = NULL;
    size_t length = 0;
    const char *source = "<h1>{{name}}</h1>";
    assert(log_template_render(source, strlen(source), values, 1,
        &output, &length) == 0);
    assert(!strcmp(output, "<h1>&lt;script&gt;&amp;&quot;&#39;</h1>"));
    assert(length == strlen(output));
    free(output);
    assert(log_template_render("{{missing}}", 11, values, 1,
        &output, &length) != 0);
    assert(output == NULL);
    assert(log_template_render("{{name", 6, values, 1,
        &output, &length) != 0);
    return 0;
}
