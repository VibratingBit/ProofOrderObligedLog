#include "institute.h"
#include "cms.h"
#include "cog.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static log_request request;
static log_response response;
static void call(const char *path,const char *body){
    memset(&response,0,sizeof(response));
    snprintf(request.path,sizeof(request.path),"%s",path);
    request.body=body;request.body_length=strlen(body);
    assert(log_institute_handle(&request,&response));
}
int main(void){
    assert(log_institute_init());
    strcpy(request.method,"GET");
    call("/api/institute/status","");
    assert(response.status==200 && strstr(response.body,"\"https\":false"));
    log_institute_set_https_ready(true);
    call("/api/institute/status","");
    assert(strstr(response.body,"\"https\":true"));
    log_institute_set_https_ready(false);
    request.secure=true;
    strcpy(request.method,"POST");strcpy(request.host,"localhost");
    strcpy(request.origin,"https://localhost");strcpy(request.peer,"127.0.0.1");
    call("/api/institute/register","username=Sshhm&password=correct-horse-battery");
    assert(response.status==409);
    call("/api/institute/setup","username=intruder&password=correct-horse-battery&confirm=correct-horse-battery");
    assert(response.status==403);
    assert(!log_institute_admin_exists());
    FILE *f=fopen("private/institute/setup.token","rb");assert(f);
    char setup[65]={0};assert(fread(setup,1,64,f)==64);fclose(f);
    char body[256];snprintf(body,sizeof(body),
        "username=Sshhm&password=correct-horse-battery&confirm=correct-horse-battery&setup=%s",setup);
    call("/api/institute/setup",body);assert(response.status==201);
    assert(log_institute_admin_exists());
    assert(strstr(response.cookie_header,"__Host-pass="));
    call("/api/institute/setup",body);assert(response.status==409);
    call("/api/institute/login","username=Sshhm&password=incorrect-password-x");
    assert(response.status==401);
    call("/api/institute/login","username=Sshhm&password=correct-horse-battery");
    assert(response.status==200);
    assert(strstr(response.cookie_header,"Secure; HttpOnly; SameSite=Strict"));
    const char *cookie=strstr(response.cookie_header,"__Host-pass=");assert(cookie);
    memcpy(request.cookie,cookie,76);request.cookie[76]=0;
    strcpy(request.method,"GET");call("/api/institute/session","");
    assert(response.status==200);
    const char *csrf=strstr(response.body,"\"csrf\":\"");assert(csrf);
    memcpy(request.csrf,csrf+8,64);request.csrf[64]=0;
    assert(log_institute_role(&request,true)==3);
    strcpy(request.origin,"https://evil.invalid");
    assert(log_institute_role(&request,true)==0);
    strcpy(request.origin,"https://localhost");
    request.secure=false;call("/api/institute/session","");assert(response.status==426);
    request.secure=true;strcpy(request.method,"POST");
    strcpy(request.path,"/api/pages");
    request.body="action=create&route=News&heading=News&description=Hello&content=World&cards=%5B%5D";
    request.body_length=strlen(request.body);memset(&response,0,sizeof(response));
    assert(log_cms_handle(&request,&response));assert(response.status==200);
    assert(log_cms_page_exists("/News"));
    request.body="action=save&route=maintenance&heading=&description=&content=&cards=%5B%5D";
    request.body_length=strlen(request.body);memset(&response,0,sizeof(response));
    assert(log_cms_handle(&request,&response));assert(response.status==200);
    request.body="action=delete&route=maintenance";
    request.body_length=strlen(request.body);memset(&response,0,sizeof(response));
    assert(log_cms_handle(&request,&response));assert(response.status==403);
    strcpy(request.peer,"127.0.0.2");
    call("/api/institute/register","username=alice&password=another-strong-password&confirm=wrong");
    assert(response.status==400);
    call("/api/institute/register","username=alice&password=another-strong-password&confirm=another-strong-password&website=spam");
    assert(response.status==400);
    call("/api/institute/register","username=alice&password=another-strong-password&confirm=another-strong-password");
    assert(response.status==201);
    assert(strstr(response.cookie_header,"__Host-pass="));
    call("/api/institute/members","action=role&username=alice&role=2");
    assert(response.status==200);
    char member[128];
    assert(!log_cog_get("private/institute/members.cog","members","alice",member,sizeof(member)));
    assert(strstr(member,"MEMBER1 2 ")==member);
    assert(log_institute_role(&request,true)==0);
    call("/api/institute/login","username=Sshhm&password=correct-horse-battery");
    assert(response.status==200);
    cookie=strstr(response.cookie_header,"__Host-pass=");assert(cookie);
    memcpy(request.cookie,cookie,76);request.cookie[76]=0;
    strcpy(request.method,"GET");call("/api/institute/session","");
    csrf=strstr(response.body,"\"csrf\":\"");assert(csrf);
    memcpy(request.csrf,csrf+8,64);request.csrf[64]=0;
    strcpy(request.method,"POST");
    call("/api/institute/members","action=delete&username=sshhm");
    assert(response.status==403);
    call("/api/institute/members","action=delete&username=alice");
    assert(response.status==200);
    assert(log_cog_get("private/institute/members.cog","members","alice",member,sizeof(member))==1);
    request.csrf[0]='z';assert(log_institute_role(&request,true)==0);
    strcpy(request.peer,"127.0.0.3");request.csrf[0]=0;
    call("/api/institute/login","username=Sshhm&password=correct-horse-battery");
    assert(response.status==200);
    cookie=strstr(response.cookie_header,"__Host-pass=");assert(cookie);
    memcpy(request.cookie,cookie,76);request.cookie[76]=0;
    strcpy(request.method,"GET");call("/api/institute/session","");
    csrf=strstr(response.body,"\"csrf\":\"");assert(csrf);
    memcpy(request.csrf,csrf+8,64);request.csrf[64]=0;
    strcpy(request.method,"POST");
    call("/api/institute/password","current=correct-horse-battery&password=new-secure-password&confirm=new-secure-password");
    assert(response.status==200);assert(log_institute_role(&request,true)==0);
    call("/api/institute/login","username=Sshhm&password=correct-horse-battery");
    assert(response.status==401);
    call("/api/institute/login","username=Sshhm&password=new-secure-password");
    assert(response.status==200);
    strcpy(request.peer,"127.0.0.4");
    for(unsigned attempt=0;attempt<11;++attempt) {
        call("/api/institute/login","username=Sshhm&password=wrong-password-value");
        assert(response.status==(attempt==10?429:401));
    }
    remove("private/cms/pages.cog");remove("private/institute/members.cog");
    puts("Institute/COG/session/CSRF/CMS tests passed");return 0;
}
