#include "assets.h"
#include "institute.h"
#include <assert.h>
#include <string.h>

int main(void) {
    log_request request = {0};
    log_response response = {0};
    strcpy(request.method, "GET");
    request.secure = true;
    const char *paths[] = {
        "/", "/index.html", "/admin", "/maintenance", "/maintenance/", "/Institute", "/acccount", "/account", "/Media", "/Media/", "/Media/index.html", "/Mail", "/Mail/Sshhm", "/media.js", "/mail.js", "/mirror-logo.png", "/design.css", "/design.js", "/favicon.ico"
    };
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); ++i) {
        strcpy(request.path, paths[i]);
        log_asset_response(&request, &response);
        assert(response.status == 200);
        assert(response.body != NULL && response.body_length > 0);
        if (!strncmp(response.content_type,"text/html",9)) {
            assert(strstr(response.body,"Go Live"));
            assert(!strstr(response.body,"workspace-content"));
        }
    }
    strcpy(request.path, "/../../pool.conf");
    log_asset_response(&request, &response);
    assert(response.status == 404);
    log_institute_set_https_ready(true);
    request.secure = false;
    strcpy(request.path, "/Institute");
    strcpy(request.host, "evil.invalid");
    log_asset_response(&request, &response);
    assert(response.status == 308);
    assert(strstr(response.cookie_header, "https://localhost/Institute"));
    assert(!strstr(response.cookie_header, "evil.invalid"));
    log_assets_free();
    return 0;
}
