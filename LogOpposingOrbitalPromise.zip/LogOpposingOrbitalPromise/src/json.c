#include "json.h"
#include <stdio.h>
#include <string.h>
void log_json_text(log_json *json, const char *text) {
    size_t length = strlen(text);
    if (json->failed || length >= json->capacity - json->used) {
        json->failed = true;
        return;
    }
    memcpy(json->data + json->used, text, length + 1);
    json->used += length;
}
void log_json_string(log_json *json, const char *text) {
    log_json_text(json, "\"");
    for (const unsigned char *p = (const unsigned char *)text; *p; ++p) {
        char escaped[8] = {0};
        if (*p == '"' || *p == '\\') {
            escaped[0] = '\\';
            escaped[1] = (char)*p;
        } else if (*p < 32) {
            snprintf(escaped, sizeof(escaped), "\\u%04x", (unsigned)*p);
        } else if (*p >= 128) {
            unsigned count = *p >= 0xc2 && *p <= 0xdf ? 2 :
                *p >= 0xe0 && *p <= 0xef ? 3 :
                *p >= 0xf0 && *p <= 0xf4 ? 4 : 0;
            unsigned point = count ? (unsigned)(*p & (0x7fU >> count)) : 0;
            bool valid = count != 0;
            for (unsigned i = 1; i < count && valid; ++i) {
                valid = p[i] && (p[i] & 0xc0) == 0x80;
                if (valid) point = (point << 6) | (p[i] & 0x3fU);
            }
            valid = valid && (count != 3 || point >= 0x800) &&
                (count != 4 || point >= 0x10000) &&
                !(point >= 0xd800 && point <= 0xdfff) && point <= 0x10ffff;
            if (valid) {
                memcpy(escaped, p, count);
                p += count - 1;
            } else {
                snprintf(escaped, sizeof(escaped), "\\u%04x", (unsigned)*p);
            }
        } else {
            escaped[0] = (char)*p;
        }
        log_json_text(json, escaped);
    }
    log_json_text(json, "\"");
}
