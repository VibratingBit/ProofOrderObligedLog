#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#endif
#include "media.h"
#include "form.h"
#include "json.h"
#include "institute.h"
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <dirent.h>
#include <sys/stat.h>
#endif
#define MEDIA_LIMIT (64UL * 1024UL * 1024UL)
static char listing[262144];
static char *file_buffer;
void log_media_free(void) {
    free(file_buffer);
    file_buffer = NULL;
}
static const char *media_type(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot || strlen(dot) > 8) return NULL;
    char ext[9];
    for (size_t i = 0; i <= strlen(dot); ++i) ext[i] = (char)tolower((unsigned char)dot[i]);
    const char *extensions[] = {
        ".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".mp4", ".webm", ".ogv",
        ".mp3", ".ogg", ".wav", ".flac", ".m4a"
    };
    const char *types[] = {
        "image/jpeg", "image/jpeg", "image/png", "image/gif", "image/webp", "image/avif",
        "video/mp4", "video/webm", "video/ogg", "audio/mpeg", "audio/ogg", "audio/wav",
        "audio/flac", "audio/mp4"
    };
    for (size_t i = 0; i < sizeof(extensions) / sizeof(*extensions); ++i) if (!strcmp(ext,
    extensions[i])) return types[i];
    return NULL;
}
static bool filename(const char *name) {
    if (!*name || *name == '.' || strlen(name) > 200) return false;
    for (const unsigned char *p = (const unsigned char *)name; *p; ++p) if (*p < 32 || strchr("/\\:%?*\"<>|",
    *p)) return false;
    return media_type(name) != NULL;
}
static bool regular_file(const char *name, char path[256]) {
    if (!filename(name)) return false;
    snprintf(path, 256, "Media/%s", name);
#ifdef _WIN32
    wchar_t wide[256];
    if (!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,wide,256)) return false;
    DWORD attributes = GetFileAttributesW(wide);
    return attributes != INVALID_FILE_ATTRIBUTES && !(attributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT));
#else
    struct stat info;
    return !lstat(path, &info) && S_ISREG(info.st_mode);
#endif
}
static FILE *open_media(const char *path) {
#ifdef _WIN32
    wchar_t wide[256];
    if (!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,path,-1,wide,256)) return NULL;
    return _wfopen(wide,L"rb");
#else
    return fopen(path,"rb");
#endif
}
static void add_file(log_json *json, const char *name, unsigned *count) {
    char path[256];
    if (*count >= 500 || !regular_file(name, path)) return;
    FILE *file = open_media(path);
    if (!file) return;
    if (fseek(file, 0, SEEK_END)) {
        fclose(file);
        return;
    }
    long size = ftell(file);
    fclose(file);
    if (size < 0 || (unsigned long)size > MEDIA_LIMIT) return;
    if ((*count)++) log_json_text(json, ",");
    log_json_text(json, "{\"name\":");
    log_json_string(json, name);
    log_json_text(json, ",\"type\":");
    log_json_string(json, media_type(name));
    char bytes[64];
    snprintf(bytes, sizeof(bytes), ",\"size\":%ld}", size);
    log_json_text(json, bytes);
}
static void reply(log_response *response, int status, const char *body) {
    response->status = status;
    response->content_type = "application/json; charset=utf-8";
    response->body = body;
    response->body_length = strlen(body);
}
bool log_media_handle(const log_request *request, log_response *response) {
    bool list = !strcmp(request->path, "/api/media");
    bool file = !strcmp(request->path, "/Media/file");
    bool direct = !strncmp(request->path, "/Media/", 7) && request->path[7] && strcmp(request->path,
    "/Media/index.html");
    if (!list && !file && !direct) return false;
    if (!log_institute_admin_exists()) {
        reply(response, 503, "{\"error\":\"Site not live\"}");
        return true;
    }
    if (strcmp(request->method, "GET")) {
        reply(response, 405, "{\"error\":\"GET required\"}");
        return true;
    }
    if (list) {
        log_json json = {
            listing, 0, sizeof(listing), false
        };
        unsigned count = 0;
        log_json_text(&json, "[");
#ifdef _WIN32
        WIN32_FIND_DATAW found;
        HANDLE search = FindFirstFileW(L"Media/*", &found);
        if (search != INVALID_HANDLE_VALUE) {
            do {
                char name[201];
                if (WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,
                    found.cFileName,-1,name,sizeof(name),NULL,NULL))
                    add_file(&json,name,&count);
            }
            while (FindNextFileW(search, &found));
            FindClose(search);
        }
#else
        DIR *directory = opendir("Media");
        if (directory) {
            struct dirent *found;
            while ((found = readdir(directory))) add_file(&json, found->d_name,
            &count);
            closedir(directory);
        }
#endif
        log_json_text(&json, "]");
        reply(response, json.failed ? 500 : 200, json.failed ? "{\"error\":\"Listing too large\"}" : listing);
        return true;
    }
    char name[201], path[256];
    if (file) {
        if (log_form_get(request->query, strlen(request->query), "name", name,
        sizeof(name))) name[0] = 0;
    }
    else {
        /* Direct paths deliberately do not decode separators or escapes. */ snprintf(name,
        sizeof(name), "%s", request->path + 7);
    }
    if (!regular_file(name, path)) {
        reply(response, 404, "{\"error\":\"Media not found\"}");
        return true;
    }
    FILE *stream = open_media(path);
    if (!stream) {
        reply(response, 404, "{}");
        return true;
    }
    if (fseek(stream, 0, SEEK_END)) {
        fclose(stream);
        reply(response, 500, "{}");
        return true;
    }
    long size = ftell(stream);
    if (size < 0 || (unsigned long)size > MEDIA_LIMIT) {
        fclose(stream);
        reply(response, 413, "{\"error\":\"64 MiB file limit\"}");
        return true;
    }
    unsigned long start = 0, end = size ? (unsigned long)size - 1 : 0;
    bool partial = request->range[0] != 0;
    if (partial) {
        const char *range = request->range;
        char *after = NULL;
        bool valid = !strncmp(range,"bytes=",6) && size > 0;
        if (valid) {
            range += 6;
            errno = 0;
            if (*range == '-') {
                ++range;
                unsigned long suffix = strtoul(range,&after,10);
                valid = *range >= '0' && *range <= '9' && !errno && after && !*after && suffix > 0;
                if (valid) start = suffix >= (unsigned long)size ? 0 : (unsigned long)size - suffix;
            }
            else {
                start = strtoul(range,&after,10);
                valid = *range >= '0' && *range <= '9' && !errno && after && *after == '-';
                if (valid && after[1]) {
                    range = after + 1;
                    errno = 0;
                    end = strtoul(range,&after,10);
                    valid = *range >= '0' && *range <= '9' && !errno && after && !*after;
                    if (end >= (unsigned long)size) end = (unsigned long)size - 1;
                }
            }
        }
        if (!valid || start > end || start >= (unsigned long)size) {
            fclose(stream);
            reply(response, 416, "{}");
            snprintf(response->cookie_header, sizeof(response->cookie_header),
            "Content-Range: bytes */%ld\r\n", size);
            return true;
        }
    }
    size_t length = size ? (size_t)(end - start + 1) : 0;
    char *buffer = realloc(file_buffer, length + 1);
    if (!buffer) {
        fclose(stream);
        reply(response, 500, "{}");
        return true;
    }
    file_buffer = buffer;
    if (fseek(stream, (long)start, SEEK_SET) || fread(buffer, 1, length, stream) != length) {
        fclose(stream);
        reply(response, 500, "{}");
        return true;
    }
    fclose(stream);
    response->status = partial ? 206 : 200;
    response->content_type = media_type(name);
    response->body = buffer;
    response->body_length = length;
    if (partial) snprintf(response->cookie_header, sizeof(response->cookie_header),
    "Accept-Ranges: bytes\r\nContent-Range: bytes %lu-%lu/%ld\r\n", start, end,
    size);
    else strcpy(response->cookie_header, "Accept-Ranges: bytes\r\n");
    return true;
}
