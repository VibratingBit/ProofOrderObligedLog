#include "console_commands.h"

#include <ctype.h>
#include <string.h>

log_command log_command_parse(const char *line) {
    char text[128];
    size_t length;

    if (line == NULL) {
        return LOG_COMMAND_UNKNOWN;
    }

    while (isspace((unsigned char)*line)) {
        ++line;
    }
    length = strlen(line);
    while (length > 0 && isspace((unsigned char)line[length - 1])) {
        --length;
    }
    if (length >= sizeof(text)) {
        return LOG_COMMAND_UNKNOWN;
    }
    for (size_t index = 0; index < length; ++index) {
        text[index] = (char)tolower((unsigned char)line[index]);
    }
    text[length] = '\0';

    if (length == 0) {
        return LOG_COMMAND_EMPTY;
    }
    if (!strcmp(text, "ports open")) {
        return LOG_COMMAND_PORTS_OPEN;
    }
    if (!strcmp(text, "ports close")) {
        return LOG_COMMAND_PORTS_CLOSE;
    }
    if (!strcmp(text, "ports status")) {
        return LOG_COMMAND_PORTS_STATUS;
    }
    if (!strcmp(text, "/wipe") || !strcmp(text, "wipe")) {
        return LOG_COMMAND_WIPE;
    }
    if (!strcmp(text, "help")) {
        return LOG_COMMAND_HELP;
    }
    if (!strcmp(text, "start")) {
        return LOG_COMMAND_START;
    }
    if (!strcmp(text, "shutdown") || !strcmp(text, "stop")) {
        return LOG_COMMAND_STOP;
    }
    if (!strcmp(text, "restart") || !strcmp(text, "reload")) {
        return LOG_COMMAND_RESTART;
    }
    if (!strcmp(text, "status")) {
        return LOG_COMMAND_STATUS;
    }
    if (!strcmp(text, "traffic")) {
        return LOG_COMMAND_TRAFFIC;
    }
    if (!strcmp(text, "config")) {
        return LOG_COMMAND_CONFIG;
    }
    if (!strcmp(text, "logs on")) {
        return LOG_COMMAND_LOGS_ON;
    }
    if (!strcmp(text, "logs off")) {
        return LOG_COMMAND_LOGS_OFF;
    }
    if (!strcmp(text, "exit") || !strcmp(text, "quit")) {
        return LOG_COMMAND_EXIT;
    }
    return LOG_COMMAND_UNKNOWN;
}
