#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#define MINIUPNP_STATICLIB
#include <miniupnpc/miniupnpc.h>
#include <miniupnpc/upnpcommands.h>
#include <miniupnpc/upnperrors.h>
#include "ports.h"
#include "ports_policy.h"
#include "smtp.h"
#include "logging.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAPPING_OWNER "PoolingArcSendSecret"
static HANDLE mapping_thread;
static HANDLE stop_event;
static log_pool_config settings;
static SRWLOCK state_lock = SRWLOCK_INIT;
static char state[200] = "Closed";
static ULONGLONG expires;

static void update_state(const char *message) {
    AcquireSRWLockExclusive(&state_lock);
    snprintf(state, sizeof(state), "%s", message);
    ReleaseSRWLockExclusive(&state_lock);
    log_write("UPNP", "%s", message);
}

/* Never replace or delete a mapping belonging to another device/app. */
static int mapping_owner(
    struct UPNPUrls *urls, struct IGDdatas *data,
    const char *port, const char *local, bool finite
) {
    char client[64] = {0};
    char internal[16] = {0};
    char description[128] = {0};
    char enabled[8] = {0};
    char duration[32] = {0};
    int result = UPNP_GetSpecificPortMappingEntry(
        urls->controlURL, data->first.servicetype, port, "TCP", NULL,
        client, internal, description, enabled, duration
    );
    if (result == 714) return 0; /* no such mapping */
    if (result != 0) {
        const char *reason = strupnperror(result);
        log_write("UPNP", "TCP %s query failed: %d (%s)", port, result,
            reason ? reason : "transport/unknown error");
        return -3;
    }
    int policy = log_ports_classify(result, client, internal,
        description, local, port);
    if (policy == 2) {
        log_write("UPNP", "TCP %s already targets this host (%s); preserving it",
            port, description);
        return 2;
    }
    if (policy == -1) {
        log_write("UPNP", "TCP %s targets %s:%s; refusing to replace it",
            port, client, internal);
        return -1;
    }
    if (finite && strtoul(duration, NULL, 10) == 0) return -2;
    return 1;
}

/* Return 1 for our mapping, 2 for an existing rule to preserve, 0 on failure. */
static int set_mapping(
    struct UPNPUrls *urls, struct IGDdatas *data,
    const char *local, const char *port, const char *lease
) {
    int before = mapping_owner(urls, data, port, local, false);
    if (before == 2) return 2;
    if (before == -1) return 0;
    if (before == -3 && !settings.upnp_legacy_compat) return 0;
    if (before == -3) {
        log_write("UPNP", "TCP %s: legacy Add-first mode; query unavailable",
            port);
    }
    int result = UPNP_AddPortMapping(
        urls->controlURL, data->first.servicetype,
        port, port, local, MAPPING_OWNER, "TCP", "", lease
    );
    bool permanent = false;
    if (result == 725 && settings.upnp_allow_permanent) {
        result = UPNP_AddPortMapping(
            urls->controlURL, data->first.servicetype,
            port, port, local, MAPPING_OWNER, "TCP", "", "0"
        );
        permanent = result == 0;
    }
    if (result != 0) {
        const char *reason = strupnperror(result);
        log_write("UPNP", "TCP %s add failed: %d (%s)", port, result,
            reason ? reason : "transport/unknown error");
        return 0;
    }
    int verified = mapping_owner(urls, data, port, local, !permanent);
    if (verified == -2 && settings.upnp_allow_permanent) permanent = true;
    else if (verified == -2) {
        UPNP_DeletePortMapping(
            urls->controlURL, data->first.servicetype, port, "TCP", ""
        );
        log_write("UPNP", "TCP %s: permanent lease rejected by configuration",
            port);
        return 0;
    }
    log_write("UPNP", "TCP %s -> %s:%s: router accepted %s; readback %s",
        port, local, port, permanent ? "permanent mapping" : "leased mapping",
        verified == -3 ? "unavailable" : "checked");
    return verified == -1 ? 0 : 1;
}

static DWORD WINAPI mapping_worker(void *argument) {
    (void)argument;
    WSADATA winsock;
    if (WSAStartup(MAKEWORD(2, 2), &winsock) != 0) {
        update_state("Winsock initialization failed");
        return 1;
    }
    int error = 0;
    struct UPNPDev *devices = upnpDiscover(2000, NULL, NULL, 0, 0, 2, &error);
    struct UPNPUrls urls = {0};
    struct IGDdatas data = {0};
    char local[64] = {0};
    char external[64] = {0};
    int valid = UPNP_GetValidIGD(
        devices, &urls, &data,
        local, sizeof(local), external, sizeof(external)
    );
    freeUPNPDevlist(devices);
    if (valid != 1) {
        update_state("No connected UPnP gateway found; check router support.");
        FreeUPNPUrls(&urls);
        WSACleanup();
        return 1;
    }
    if (strcmp(settings.http_bind, "0.0.0.0") &&
        strcmp(settings.http_bind, local)) {
        update_state("Bind HTTP to 0.0.0.0 or the LAN address before opening ports.");
        FreeUPNPUrls(&urls);
        WSACleanup();
        return 1;
    }
    char ports[3][16];
    snprintf(ports[0], sizeof(ports[0]), "%u", (unsigned)settings.http_port);
    unsigned count = 1;
    if (settings.https_port &&
        (!settings.https_bind[0] || !strcmp(settings.https_bind, "0.0.0.0") ||
         !strcmp(settings.https_bind, local))) {
        snprintf(ports[1], sizeof(ports[1]), "%u", (unsigned)settings.https_port);
        count = 2;
    }
    if (settings.smtp_enabled && log_smtp_running() &&
        (!strcmp(settings.smtp_bind,"0.0.0.0")||!strcmp(settings.smtp_bind,local))) {
        snprintf(ports[count++],sizeof(ports[0]),"%u",(unsigned)settings.smtp_port);
    }
    char lease[24];
    snprintf(lease, sizeof(lease), "%u", settings.upnp_lease);
    bool owned[3] = {false, false, false};
    log_write("UPNP", "Gateway WAN=%s; mapping target=%s; requested lease=%ss",
        external, local, lease);
    while (WaitForSingleObject(stop_event, 0) != WAIT_OBJECT_0) {
        bool all = true;
        for (unsigned i = 0; i < count; ++i) {
            int success = set_mapping(&urls, &data, local, ports[i], lease);
            if (success == 1) owned[i] = true;
            all = all && success != 0;
        }
        AcquireSRWLockExclusive(&state_lock);
        expires = all ? GetTickCount64() + settings.upnp_lease * 1000ULL : 0;
        ReleaseSRWLockExclusive(&state_lock);
        update_state(all ? "Router mappings accepted/preserved; maintaining"
                         : "One or more mappings failed; retrying later");
        DWORD delay = all ? settings.upnp_lease * 500U : 30000U;
        if (WaitForSingleObject(stop_event, delay) == WAIT_OBJECT_0) break;
    }
    for (unsigned i = 0; i < count; ++i) {
        if (owned[i] && mapping_owner(&urls, &data, ports[i], local, false) == 1) {
            int result = UPNP_DeletePortMapping(
                urls.controlURL, data.first.servicetype, ports[i], "TCP", NULL
            );
            log_write("UPNP", "TCP %s remove: %s", ports[i],
                result == 0 ? "OK" : "failed; requested lease may expire later");
        }
    }
    FreeUPNPUrls(&urls);
    WSACleanup();
    update_state("Closed; owned mappings removal attempted");
    return 0;
}

void log_ports_close(void) {
    if (mapping_thread == NULL) return;
    SetEvent(stop_event);
    WaitForSingleObject(mapping_thread, INFINITE);
    CloseHandle(mapping_thread);
    CloseHandle(stop_event);
    mapping_thread = NULL;
    stop_event = NULL;
    AcquireSRWLockExclusive(&state_lock);
    expires = 0;
    ReleaseSRWLockExclusive(&state_lock);
}

void log_ports_open(const log_pool_config *config) {
    if (mapping_thread != NULL) {
        if (WaitForSingleObject(mapping_thread, 0) != WAIT_OBJECT_0) {
            log_ports_status();
            return;
        }
        log_ports_close();
    }
    settings = *config;
    stop_event = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (stop_event == NULL) return;
    update_state("Discovering local UPnP gateway...");
    mapping_thread = CreateThread(NULL, 0, mapping_worker, NULL, 0, NULL);
    if (mapping_thread == NULL) {
        CloseHandle(stop_event);
        stop_event = NULL;
        update_state("Could not create mapping worker");
    }
}

void log_ports_status(void) {
    AcquireSRWLockShared(&state_lock);
    ULONGLONG now = GetTickCount64();
    unsigned long long remaining = expires > now ? (expires - now) / 1000 : 0;
    log_write("UPNP", "%s | requested renewal window: %llus", state, remaining);
    ReleaseSRWLockShared(&state_lock);
}
