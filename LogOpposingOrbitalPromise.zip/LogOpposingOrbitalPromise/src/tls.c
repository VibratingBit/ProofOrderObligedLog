#include "tls.h"
#include "logging.h"

#include <openssl/err.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#ifdef _WIN32
#include <windows.h>
#endif

int log_tls_resolve_path(const char *source, char *output, size_t capacity) {
    if (source == NULL || output == NULL || capacity == 0) return -1;
    bool local = !strncmp(source, "/ssl/", 5) ||
        !strncmp(source, "\\ssl\\", 5);
    int length = snprintf(output, capacity, "%s%s", local ? "." : "", source);
    return length >= 0 && (size_t)length < capacity ? 0 : -1;
}

static bool ssl_alias(const char *path) {
    return path && (!strncmp(path,"/ssl/",5) ||
        !strncmp(path,"\\ssl\\",5));
}

static bool readable(const char *path, int *failure) {
    errno = 0;
    FILE *file = fopen(path,"rb");
    *failure = file ? 0 : errno;
    if (!file) return false;
    fclose(file);
    return true;
}

static void display_path(const char *path, char output[2048]) {
#ifdef _WIN32
    DWORD count = GetFullPathNameA(path,2048,output,NULL);
    if (count && count < 2048) return;
#endif
    snprintf(output,2048,"%s",path);
}

static void file_error(const char *kind, const char *path, int failure) {
    char full[2048];
    display_path(path,full);
    log_write("TLS","Cannot read %s: %s | %s (errno %d)",
        kind,full,strerror(failure),failure);
}

static void crypto_error(const char *stage, const char *path) {
    char full[2048];
    display_path(path,full);
    log_write("TLS","%s: %s",stage,full);
    unsigned long code;
    unsigned count = 0;
    while ((code = ERR_get_error()) && count++ < 8) {
        char detail[256];
        ERR_error_string_n(code,detail,sizeof(detail));
        log_write("TLS","%s",detail);
    }
    ERR_clear_error();
}

static int no_password(char *buffer, int size, int writing, void *unused) {
    (void)buffer;
    (void)size;
    (void)writing;
    (void)unused;
    /* A background listener must never wait on a hidden password prompt. */
    return 0;
}

SSL_CTX *log_tls_context(const char *certificate, const char *key) {
    char certificate_path[1024];
    char key_path[1024];
    if (!certificate || !*certificate || !key || !*key ||
        log_tls_resolve_path(certificate,certificate_path,sizeof(certificate_path)) ||
        log_tls_resolve_path(key,key_path,sizeof(key_path))) {
        log_write("TLS","Certificate/private-key path is empty or too long.");
        return NULL;
    }
    int certificate_error, key_error;
    bool certificate_ok = readable(certificate_path,&certificate_error);
    bool key_ok = readable(key_path,&key_error);
    /* /ssl is an application shorthand. Only look elsewhere when BOTH
       Launch files are absent; never mix keys and certificates across folders
       or conceal an unreadable, malformed or mismatched configured pair. */
    if (!certificate_ok && !key_ok && certificate_error == ENOENT &&
        key_error == ENOENT && ssl_alias(certificate) && ssl_alias(key)) {
        /* Also accept the user's LoveShip pair next to the source root,
           one folder above Launch, without moving or duplicating the key. */
        if (!strcmp(certificate + 5,"LoveShip-chain.pem") &&
            !strcmp(key + 5,"LoveShip-key.pem")) {
            int ec, ek;
            if (readable("../LoveShip-chain.pem",&ec) &&
                readable("../LoveShip-key.pem",&ek)) {
                strcpy(certificate_path,"../LoveShip-chain.pem");
                strcpy(key_path,"../LoveShip-key.pem");
                certificate_ok = key_ok = true;
                log_write("TLS","Using LoveShip certificate/key from the project root.");
            }
        }
        const char *prefixes[] = {"..", "../..", ""};
        for (unsigned i = 0; !certificate_ok && i < 3; ++i) {
#ifndef _WIN32
            if (i == 2) break;
#endif
            char candidate_cert[1024], candidate_key[1024];
            int nc = snprintf(candidate_cert,sizeof(candidate_cert),"%s%s",
                prefixes[i],certificate);
            int nk = snprintf(candidate_key,sizeof(candidate_key),"%s%s",
                prefixes[i],key);
            if (nc < 0 || nk < 0 || (size_t)nc >= sizeof(candidate_cert) ||
                (size_t)nk >= sizeof(candidate_key)) continue;
            int ec, ek;
            if (readable(candidate_cert,&ec) && readable(candidate_key,&ek)) {
                strcpy(certificate_path,candidate_cert);
                strcpy(key_path,candidate_key);
                certificate_ok = key_ok = true;
                char full[2048];
                display_path(candidate_cert,full);
                log_write("TLS","Using existing /ssl certificate pair: %s",full);
                break;
            }
        }
    }
    if (!certificate_ok || !key_ok) {
        if (!certificate_ok) file_error("certificate chain",certificate_path,certificate_error);
        if (!key_ok) file_error("private key",key_path,key_error);
        log_write("TLS","Check https_certificate and https_private_key in pool.conf.");
        return NULL;
    }
    OPENSSL_init_ssl(OPENSSL_INIT_NO_LOAD_CONFIG,NULL);
    ERR_clear_error();
    errno = 0;
    SSL_CTX *context = SSL_CTX_new(TLS_server_method());
    if (!context) {
        crypto_error("Cannot create TLS context",certificate_path);
        return NULL;
    }
    SSL_CTX_set_default_passwd_cb(context,no_password);
    if (SSL_CTX_set_min_proto_version(context,TLS1_2_VERSION) != 1) {
        crypto_error("Cannot configure TLS version",certificate_path);
        goto failed;
    }
    if (SSL_CTX_use_certificate_chain_file(context,certificate_path) != 1) {
        crypto_error("Cannot load PEM certificate chain",certificate_path);
        goto failed;
    }
    ERR_clear_error();
    errno = 0;
    if (SSL_CTX_use_PrivateKey_file(context,key_path,SSL_FILETYPE_PEM) != 1) {
        crypto_error("Cannot load PEM private key (encrypted keys need unlocking)",key_path);
        goto failed;
    }
    if (SSL_CTX_check_private_key(context) != 1) {
        crypto_error("Certificate and private key do not match",key_path);
        goto failed;
    }
    SSL_CTX_set_options(context,SSL_OP_NO_COMPRESSION);
    ERR_clear_error();
    return context;
failed:
    SSL_CTX_free(context);
    return NULL;
}

int log_stream_receive(SOCKET socket_handle, SSL *tls, char *data, int size) {
    if (tls != NULL) {
        return SSL_read(tls, data, size);
    }
#ifdef _WIN32
    return recv(socket_handle, data, size, 0);
#else
    return (int)recv(socket_handle, data, (size_t)size, 0);
#endif
}

int log_stream_send(
    SOCKET socket_handle,
    SSL *tls,
    const char *data,
    int size
) {
    if (tls != NULL) {
        return SSL_write(tls, data, size);
    }
#ifdef _WIN32
    return send(socket_handle, data, size, 0);
#else
    return (int)send(socket_handle, data, (size_t)size, 0);
#endif
}

const char *log_tls_version(void) {
    return OpenSSL_version(OPENSSL_VERSION);
}

int log_tls_accept(SSL *tls, const char *peer) {
    ERR_clear_error();
    errno = 0;
#ifdef _WIN32
    WSASetLastError(0);
#endif
    int result = SSL_accept(tls);
    if (result == 1) return 1;
    int saved_errno = errno;
    int ssl_error = SSL_get_error(tls, result);
    int socket_error = 0;
#ifdef _WIN32
    socket_error = WSAGetLastError();
#endif
    char detail[256] = "No TLS alert; peer closed or socket timeout";
    unsigned long error = ERR_get_error();
    if (error != 0) ERR_error_string_n(error, detail, sizeof(detail));
    log_write("TLS", "%s handshake failed: SSL=%d socket=%d errno=%d | %s",
        peer, ssl_error, socket_error, saved_errno, detail);
    ERR_clear_error();
    return 0;
}
