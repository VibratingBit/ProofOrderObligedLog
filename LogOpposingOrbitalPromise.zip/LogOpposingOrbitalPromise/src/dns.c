#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include "dns.h"
#include "logging.h"
#include <string.h>

static SOCKET socket_handle = INVALID_SOCKET;
static HANDLE worker;
static volatile LONG stopping;
static log_pool_config settings;

/* Local diagnostic DNS endpoint: allowlisted A lookups through Windows DNS.
   Not a recursive resolver, authoritative registrar replacement or open proxy. */
static DWORD WINAPI dns_worker(void *unused) {
    (void)unused;
    while (!InterlockedCompareExchange(&stopping, 0, 0)) {
        fd_set ready;
        FD_ZERO(&ready);
        FD_SET(socket_handle, &ready);
        struct timeval timeout = {0, 200000};
        if (select(0, &ready, NULL, NULL, &timeout) <= 0) continue;
        unsigned char packet[512];
        struct sockaddr_in peer;
        int peer_size = sizeof(peer);
        int length = recvfrom(socket_handle, (char *)packet, sizeof(packet), 0,
            (struct sockaddr *)&peer, &peer_size);
        if (length < 17 || packet[2] & 0x80 || packet[4] || packet[5] != 1) {
            continue;
        }
        size_t position = 12, used = 0;
        char name[254];
        bool valid = true;
        while (position < (size_t)length && packet[position]) {
            unsigned size = packet[position++];
            if (size > 63 || position + size >= (size_t)length ||
                used + size + 1 >= sizeof(name)) { valid = false; break; }
            if (used) name[used++] = '.';
            memcpy(name + used, packet + position, size);
            used += size;
            position += size;
        }
        if (!valid || position + 5 > (size_t)length) continue;
        name[used] = 0;
        ++position;
        bool type_a = packet[position] == 0 && packet[position + 1] == 1 &&
            packet[position + 2] == 0 && packet[position + 3] == 1;
        position += 4;
        bool allowed = !_stricmp(name, settings.hostname);
        for (unsigned i = 0; i < settings.domain_count; ++i) {
            allowed |= !_stricmp(name, settings.domains[i]);
        }
        struct addrinfo hints = {0}, *answer = NULL;
        hints.ai_family = AF_INET;
        int code = allowed && type_a ?
            getaddrinfo(name, NULL, &hints, &answer) : -1;
        if (code == 0 && answer == NULL) code = -1;
        unsigned char address[4];
        if (code == 0 && answer != NULL) {
            memcpy(address,
                &((struct sockaddr_in *)answer->ai_addr)->sin_addr, 4);
        }
        if (answer) freeaddrinfo(answer);
        packet[2] = (unsigned char)(0x80 | (packet[2] & 1));
        packet[3] = allowed ? (code == 0 ? 0 : 2) : 5;
        memset(packet + 6, 0, 6);
        if (allowed && type_a && code == 0 && position + 16 <= sizeof(packet)) {
            const unsigned char record[] = {
                0xc0,12,0,1,0,1,0,0,0,60,0,4
            };
            memcpy(packet + position, record, sizeof(record));
            memcpy(packet + position + 12, address, 4);
            position += 16;
            packet[7] = 1;
        }
        sendto(socket_handle, (char *)packet, (int)position, 0,
            (struct sockaddr *)&peer, peer_size);
    }
    return 0;
}

bool log_dns_start(const log_pool_config *config) {
    if (!config->dns_enabled) return true;
    if (strcmp(config->dns_bind, "127.0.0.1")) {
        log_write("DNS", "Diagnostic DNS must remain loopback-only.");
        return false;
    }
    WSADATA data;
    if (WSAStartup(MAKEWORD(2,2), &data)) return false;
    settings = *config;
    socket_handle = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    struct sockaddr_in address = {0};
    address.sin_family = AF_INET;
    address.sin_port = htons(config->dns_port);
    InetPtonA(AF_INET, config->dns_bind, &address.sin_addr);
    if (socket_handle == INVALID_SOCKET || bind(socket_handle,
            (struct sockaddr *)&address, sizeof(address)) == SOCKET_ERROR) {
        log_write("DNS", "Local UDP %u bind failed (Winsock %d)",
            (unsigned)config->dns_port, WSAGetLastError());
        if (socket_handle != INVALID_SOCKET) closesocket(socket_handle);
        socket_handle = INVALID_SOCKET;
        WSACleanup();
        return false;
    }
    InterlockedExchange(&stopping, 0);
    worker = CreateThread(NULL, 0, dns_worker, NULL, 0, NULL);
    if (!worker) { closesocket(socket_handle); WSACleanup(); return false; }
    log_write("DNS", "Local diagnostic A resolver on 127.0.0.1:%u",
        (unsigned)config->dns_port);
    return true;
}

void log_dns_stop(void) {
    if (!worker) return;
    InterlockedExchange(&stopping, 1);
    WaitForSingleObject(worker, INFINITE);
    CloseHandle(worker);
    worker = NULL;
    closesocket(socket_handle);
    socket_handle = INVALID_SOCKET;
    WSACleanup();
}
