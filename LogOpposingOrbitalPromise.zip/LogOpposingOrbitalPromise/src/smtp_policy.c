#include "smtp_policy.h"
#include <string.h>
#include <ctype.h>
static int ascii_ncompare(const char *a,const char *b,size_t n){
    for(size_t i=0;i<n;++i){
        int x=tolower((unsigned char)a[i]),y=tolower((unsigned char)b[i]);
        if(x!=y)return x-y;
        if(!x)return 0;
    }
    return 0;
}
static int ascii_compare(const char *a,const char *b){
    size_t x=strlen(a),y=strlen(b);
    return x==y?ascii_ncompare(a,b,x):1;
}
bool log_smtp_address(const char *command,char *output,size_t capacity){
    const char *begin=strchr(command,'<'),*end=begin?strchr(begin,'>'):NULL;
    if(!begin||!end||(size_t)(end-begin)>=capacity)return false;
    for(const char *p=command;p<begin;++p)if(*p!=' '&&*p!='\t')return false;
    if(end[1])return false;
    size_t n=(size_t)(end-begin-1);
    memcpy(output,begin+1,n);
    output[n]=0;
    for(size_t i=0;i<n;++i){
        unsigned char c=(unsigned char)output[i];
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')|| strchr(".@_+-",
        c)))return false;
    }
    return true;
}
bool log_smtp_recipient(const log_pool_config *config,const char *text){
    const char *at=strchr(text,'@');
    if(!at||at-text!=5||ascii_ncompare(text,"Sshhm",5))return false;
    if(!ascii_compare(at+1,config->hostname))return true;
    for(unsigned i=0;i<config->domain_count;++i) if(!ascii_compare(at+1,config->domains[i]))return true;
    return false;
}
