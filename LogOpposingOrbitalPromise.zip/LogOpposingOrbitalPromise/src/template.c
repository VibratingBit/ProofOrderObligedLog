#include "template.h"
#include <stdlib.h>
#include <string.h>

#define TEMPLATE_LIMIT 2097152U

static int append(char *out, size_t *used, const char *text, size_t size) {
    if (size > TEMPLATE_LIMIT - *used) return -1;
    memcpy(out + *used, text, size);
    *used += size;
    return 0;
}

int log_template_render(
    const char *source,
    size_t length,
    const log_template_value *values,
    size_t count,
    char **output,
    size_t *output_length
) {
    if (output == NULL || output_length == NULL) return -1;
    *output = NULL;
    *output_length = 0;
    if (source == NULL || length > TEMPLATE_LIMIT ||
        (count > 0 && values == NULL)) return -1;
    char *result = malloc(TEMPLATE_LIMIT + 1);
    if (result == NULL) return -1;
    size_t used = 0;
    for (size_t position = 0; position < length;) {
        if (position + 1 < length && source[position] == '{' &&
            source[position + 1] == '{') {
            size_t end = position + 2;
            while (end + 1 < length &&
                !(source[end] == '}' && source[end + 1] == '}')) ++end;
            if (end + 1 >= length) goto failure;
            const char *value = NULL;
            for (size_t i = 0; i < count; ++i) {
                if (values[i].name != NULL &&
                    strlen(values[i].name) == end - position - 2 &&
                    !memcmp(values[i].name, source + position + 2,
                        end - position - 2)) {
                    value = values[i].value;
                    break;
                }
            }
            if (value == NULL) goto failure;
            for (const char *it = value; *it; ++it) {
                const char *escaped = NULL;
                switch (*it) {
                    case '&': escaped = "&amp;"; break;
                    case '<': escaped = "&lt;"; break;
                    case '>': escaped = "&gt;"; break;
                    case '"': escaped = "&quot;"; break;
                    case '\'': escaped = "&#39;"; break;
                }
                if (append(result, &used, escaped ? escaped : it,
                    escaped ? strlen(escaped) : 1)) goto failure;
            }
            position = end + 2;
        } else {
            if (append(result, &used, source + position, 1)) goto failure;
            ++position;
        }
    }
    result[used] = '\0';
    *output = result;
    *output_length = used;
    return 0;
failure:
    free(result);
    return -1;
}
