#include "assets.h"
#include "template.h"
#include "cms.h"
#include "institute.h"
#include "media.h"
#include "mail.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static char *asset_buffer;
static log_pool_config site_config;

void log_assets_configure(const log_pool_config *config) {
    site_config = *config;
    log_mail_configure(config);
}

void log_assets_free(void) {
    log_media_free();
    free(asset_buffer);
    asset_buffer = NULL;
}

void log_asset_response(const log_request *request, log_response *response) {
    if ((!strcmp(request->path,"/Institute") ||
         !strcmp(request->path,"/Institute/")) && !request->secure &&
        log_institute_https_ready()) {
        char host[256];
        snprintf(host,sizeof(host),"%s",request->host);
        char *port=strchr(host,':');if(port)*port=0;
        bool sane=*host!=0;
        for(const char *p=host;*p;++p) {
            if(!isalnum((unsigned char)*p)&&*p!='.'&&*p!='-')sane=false;
        }
        bool allowed=sane&&!strcmp(host,site_config.hostname);
        for(unsigned i=0;i<site_config.domain_count;++i)
            allowed|=sane&&!strcmp(host,site_config.domains[i]);
        if(!allowed)snprintf(host,sizeof(host),"%s",
            site_config.hostname[0]?site_config.hostname:"localhost");
        response->status=308;
        response->content_type="text/plain; charset=utf-8";
        response->body="Use HTTPS for Institute";
        response->body_length=strlen(response->body);
        if(site_config.https_port&&site_config.https_port!=443)
            snprintf(response->cookie_header,sizeof(response->cookie_header),
                "Location: https://%s:%u/Institute\r\n",host,
                (unsigned)site_config.https_port);
        else snprintf(response->cookie_header,sizeof(response->cookie_header),
            "Location: https://%s/Institute\r\n",host);
        return;
    }
    const char *file = NULL;
    const char *type = "text/html; charset=utf-8";
    if (!strcmp(request->path, "/") ||
        !strcmp(request->path, "/index.html") ||
        !strcmp(request->path, "/admin")) {
        file = "entry/index.html";
    } else if (!strcmp(request->path, "/maintenance") ||
        !strcmp(request->path, "/maintenance/")) {
        file = "entry/maintenance.html";
    } else if (!strcmp(request->path, "/Institute") ||
        !strcmp(request->path, "/Institute/")) {
        file = "entry/institute.html";
    } else if (!strcmp(request->path,"/Media") || !strcmp(request->path,"/Media/") ||
        !strcmp(request->path,"/Media/index.html")) {
        file = "Media/index.html";
    } else if (!strcmp(request->path,"/Mail") || !strcmp(request->path,"/Mail/") ||
        !strcmp(request->path,"/Mail/Sshhm")) {
        file = "entry/mail.html";
    } else if (log_cms_page_exists(request->path)) {
        file = "entry/index.html";
    } else if (!strcmp(request->path,"/acccount")||!strcmp(request->path,"/account")) {
        file="entry/account.html";
    } else if (!strcmp(request->path, "/mirror-logo.png")) {
        file = "entry/mirror-logo.png";
        type = "image/png";
    } else if (!strcmp(request->path, "/design.css")) {
        file = "entry/design.css";
        type = "text/css; charset=utf-8";
    } else if (!strcmp(request->path,"/media.js")) {
        file = "entry/media.js";
        type = "text/javascript; charset=utf-8";
    } else if (!strcmp(request->path,"/mail.js")) {
        file = "entry/mail.js";
        type = "text/javascript; charset=utf-8";
    } else if (!strcmp(request->path, "/design.js")) {
        file = "entry/design.js";
        type = "text/javascript; charset=utf-8";
    } else if (!strcmp(request->path, "/favicon.ico")) {
        file = "entry/honeycomb.svg";
        type = "image/svg+xml";
    }
    response->status = 404;
    response->content_type = "text/plain; charset=utf-8";
    response->body = "Not Found";
    response->body_length = 9;
    if (file == NULL) return;
    if (!log_institute_admin_exists() && !strncmp(type,"text/html",9)) {
        file="entry/go-live.html";
    }
    FILE *stream = fopen(file, "rb");
    if (stream == NULL) {
        response->status = 500;
        response->body = "Missing site asset; run log.bat.";
        response->body_length = strlen(response->body);
        return;
    }
    if (fseek(stream, 0, SEEK_END) != 0) { fclose(stream); return; }
    long size = ftell(stream);
    if (size < 0 || size > 2097152 || fseek(stream, 0, SEEK_SET) != 0) {
        fclose(stream);
        return;
    }
    char *next = malloc((size_t)size + 1);
    if (next == NULL) { fclose(stream); return; }
    size_t read = fread(next, 1, (size_t)size, stream);
    fclose(stream);
    if (read != (size_t)size) { free(next); return; }
    next[read] = '\0';
    if (!strcmp(file, "entry/index.html") ||
        !strcmp(file, "entry/maintenance.html") ||
        !strcmp(file, "entry/institute.html") ||
        !strcmp(file,"entry/go-live.html")||!strcmp(file,"entry/account.html") ||
        !strcmp(file,"Media/index.html") || !strcmp(file,"entry/mail.html")) {
        char heading[257]="Build entry transaction";
        char description[1025]="Threaded canvas, Expand cards for interaction / view.";
        char custom[257];
        const char *subtitle="allowance liberation lock.";
        if(!log_cms_field(request->path,"heading",custom,sizeof(custom))&&*custom){
            strcpy(heading,custom);subtitle="";
        }
        char custom_description[1025];
        if(!log_cms_field(request->path,"description",custom_description,
                sizeof(custom_description)))strcpy(description,custom_description);
        const log_template_value values[] = {
            {"site.title", site_config.site_title},
            {"site.tagline", site_config.site_tagline},
            {"site.hostname", site_config.hostname},
            {"page.heading", heading},
            {"page.subtitle", subtitle},
            {"page.description", description}
        };
        char *rendered = NULL;
        size_t rendered_length = 0;
        int status = log_template_render(next, read, values,
            sizeof(values) / sizeof(values[0]), &rendered, &rendered_length);
        free(next);
        if (status != 0) {
            response->status = 500;
            response->body = "Invalid HTML template";
            response->body_length = strlen(response->body);
            return;
        }
        next = rendered;
        read = rendered_length;
    }
    log_assets_free();
    asset_buffer = next;
    response->status = 200;
    response->content_type = type;
    response->body = asset_buffer;
    response->body_length = read;
}
