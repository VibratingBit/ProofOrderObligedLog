#include "store.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <sddl.h>
#include <direct.h>
#include <stdio.h>
#include <stdlib.h>
int log_store_replace(const char *source, const char *destination) {
    return MoveFileExA(source,destination, MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH) ? 0 : -1;
}
bool log_store_prepare(void) {
    _mkdir("private");
    _mkdir("private/institute");
    _mkdir("private/cms");
    _mkdir("private/mail");
    const char *mail_paths[] = {
        "Mail", "Mail/Sshhm", "Mail/Sshhm/inbox", "Mail/Sshhm/sent", "Mail/Sshhm/archive",
        "Mail/Sshhm/blocked", "Mail/Sshhm/outbox"
    };
    for (unsigned i = 0; i < 7; ++i) _mkdir(mail_paths[i]);
    PSECURITY_DESCRIPTOR descriptor=NULL;
    HANDLE token_handle;
    if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&token_handle))return false;
    DWORD required=0;
    GetTokenInformation(token_handle,TokenUser,NULL,0,&required);
    TOKEN_USER *user=malloc(required);
    if(!user){
        CloseHandle(token_handle);
        return false;
    }
    bool found=GetTokenInformation(token_handle,TokenUser,user,required,&required)!=0;
    CloseHandle(token_handle);
    LPSTR sid=NULL;
    if(!found||!ConvertSidToStringSidA(user->User.Sid,&sid)){
        free(user);
        return false;
    }
    free(user);
    char sddl[512];
    snprintf(sddl,sizeof(sddl), "D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;%s)",
    sid);
    LocalFree(sid);
    if(!ConvertStringSecurityDescriptorToSecurityDescriptorA( sddl,SDDL_REVISION_1,
    &descriptor,NULL))return false;
    bool ok=SetFileSecurityA("private/institute", DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,
    descriptor)!=0;
    ok=ok&&SetFileSecurityA("private/cms", DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,
    descriptor)!=0;
    ok=ok&&SetFileSecurityA("private/mail", DACL_SECURITY_INFORMATION|PROTECTED_DACL_SECURITY_INFORMATION,
    descriptor)!=0;
    for (unsigned i = 0; i < 7; ++i) ok = SetFileSecurityA(mail_paths[i], DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
    descriptor) != 0 && ok;
    LocalFree(descriptor);
    return ok;
}
#else
#include <stdio.h>
#include <sys/stat.h>
int log_store_replace(const char *a,const char *b){
    return rename(a,b);
}
bool log_store_prepare(void){
    mkdir("private",0700);
    mkdir("private/institute",0700);
    mkdir("private/cms",0700);
    mkdir("private/mail",0700);
    const char *paths[] = {
        "Mail", "Mail/Sshhm", "Mail/Sshhm/inbox", "Mail/Sshhm/sent", "Mail/Sshhm/archive",
        "Mail/Sshhm/blocked", "Mail/Sshhm/outbox"
    };
    for (unsigned i = 0; i < 7; ++i) {
        mkdir(paths[i],0700);
        if (chmod(paths[i],0700)) return false;
    }
    return chmod("private/institute",0700)==0&&chmod("private/cms",0700)==0&&chmod("private/mail",
    0700)==0;
}
#endif
