#include "cog.h"
#include "store.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define ROWS 512
#define VALUE_LIMIT 131072U
#define FILE_LIMIT 8388608L
typedef struct {
    char *key;
    char *value;
}
row;
typedef struct {
    row rows[ROWS];
    size_t count;
}
document;
static void release(document *d){
    if(!d)return;
    for(size_t i=0;i<d->count;++i){
        free(d->rows[i].key);
        free(d->rows[i].value);
    }
    free(d);
}
static int hex(char c){
    if(c>='0'&&c<='9')return c-'0';
    if(c>='a'&&c<='f')return c-'a'+10;
    return -1;
}
static char *decode(const char *text,size_t maximum){
    size_t length=strlen(text);
    if(length%2||length/2>maximum)return NULL;
    char *out=malloc(length/2+1);
    if(!out)return NULL;
    for(size_t i=0;i<length;i+=2){
        int a=hex(text[i]),b=hex(text[i+1]);
        if(a<0||b<0||(a==0&&b==0)){
            free(out);
            return NULL;
        }
        out[i/2]=(char)(a*16+b);
    }
    out[length/2]=0;
    return out;
}
static char *duplicate(const char *text){
    size_t n=strlen(text)+1;
    char *out=malloc(n);
    if(out)memcpy(out,text,n);
    return out;
}
static document *load(const char *path,const char *table){
    if(!*table||strlen(table)>32)return NULL;
    for(const char *p=table;*p;++p)if((*p<'a'||*p>'z')&&*p!='_')return NULL;
    document *d=calloc(1,sizeof(*d));
    if(!d)return NULL;
    FILE *f=fopen(path,"rb");
    if(!f){
        if(errno==ENOENT)return d;
        release(d);
        return NULL;
    }
    if(fseek(f,0,SEEK_END)){
        fclose(f);
        release(d);
        return NULL;
    }
    long size=ftell(f);
    if(size<0||size>FILE_LIMIT){
        fclose(f);
        release(d);
        return NULL;
    }
    rewind(f);
    char *data=malloc((size_t)size+1);
    if(!data){
        fclose(f);
        release(d);
        return NULL;
    }
    size_t n=fread(data,1,(size_t)size,f);
    fclose(f);
    data[n]=0;
    char header[80];
    snprintf(header,sizeof(header),"COG 1\nTABLE %s\n",table);
    if(n!=(size_t)size||memchr(data,0,n)||strncmp(data,header,strlen(header))){
        free(data);
        release(d);
        return NULL;
    }
    char *cursor=data+strlen(header);
    while(*cursor){
        char *end=strchr(cursor,'\n');
        if(!end||strncmp(cursor,"ROW ",4)||d->count==ROWS)goto invalid;
        *end=0;
        char *space=strchr(cursor+4,' ');
        if(!space)goto invalid;
        *space=0;
        row next={
            decode(cursor+4,128),decode(space+1,VALUE_LIMIT)
        };
        if(!next.key||!next.value||!*next.key){
            free(next.key);
            free(next.value);
            goto invalid;
        }
        for(size_t i=0;i<d->count;++i)if(!strcmp(d->rows[i].key,next.key)){
            free(next.key);
            free(next.value);
            goto invalid;
        }
        d->rows[d->count++]=next;
        cursor=end+1;
    }
    free(data);
    return d;
    invalid: free(data);
    release(d);
    return NULL;
}
static bool emit(FILE *f,const char *text){
    const char *digits="0123456789abcdef";
    for(const unsigned char *p=(const unsigned char *)text;*p;++p){
        if(fputc(digits[*p>>4],f)==EOF||fputc(digits[*p&15],f)==EOF)return false;
    }
    return true;
}
static int save(const char *path,const char *table,document *d){
    size_t total=80;
    for(size_t i=0;i<d->count;++i)total+=6+2*(strlen(d->rows[i].key)+strlen(d->rows[i].value));
    if(total>FILE_LIMIT)return -1;
    char temporary[1024];
    if(snprintf(temporary,sizeof(temporary),"%s.next",path)>=(int)sizeof(temporary))return -1;
    FILE *f=fopen(temporary,"wb");
    if(!f)return -1;
    bool ok=fprintf(f,"COG 1\nTABLE %s\n",table)>0;
    for(size_t i=0;i<d->count&&ok;++i){
        ok=fputs("ROW ",f)>=0&&emit(f,d->rows[i].key)&&fputc(' ',f)!=EOF&& emit(f,
        d->rows[i].value)&&fputc('\n',f)!=EOF;
    }
    if(fclose(f))ok=false;
    if(!ok){
        remove(temporary);
        return -1;
    }
    return log_store_replace(temporary,path);
}
int log_cog_get(const char *p,const char *t,const char *k,char *v,size_t capacity){
    document *d=load(p,t);
    if(!d)return -1;
    int result=1;
    for(size_t i=0;i<d->count;++i)if(!strcmp(k,d->rows[i].key)){
        size_t n=strlen(d->rows[i].value);
        if(n>=capacity)result=-1;
        else{
            memcpy(v,d->rows[i].value,n+1);
            result=0;
        }
        break;
    }
    release(d);
    return result;
}
int log_cog_put(const char *p,const char *t,const char *k,const char *v,bool insert){
    if(!*k||strlen(k)>128||strlen(v)>VALUE_LIMIT)return -1;
    document *d=load(p,t);
    if(!d)return -1;
    size_t index=d->count;
    for(size_t i=0;i<d->count;++i)if(!strcmp(k,d->rows[i].key))index=i;
    if(index<d->count&&insert){
        release(d);
        return 1;
    }
    if(index==d->count){
        if(d->count==ROWS){
            release(d);
            return -1;
        }
        d->rows[index].key=duplicate(k);
        d->count++;
    }
    free(d->rows[index].value);
    d->rows[index].value=duplicate(v);
    int result=d->rows[index].key&&d->rows[index].value?save(p,t,d):-1;
    release(d);
    return result;
}
int log_cog_remove(const char *p,const char *t,const char *k){
    document *d=load(p,t);
    if(!d)return -1;
    for(size_t i=0;i<d->count;++i)if(!strcmp(k,d->rows[i].key)){
        free(d->rows[i].key);
        free(d->rows[i].value);
        memmove(d->rows+i,d->rows+i+1,(d->count-i-1)*sizeof(row));
        --d->count;
        int result=save(p,t,d);
        release(d);
        return result;
    }
    release(d);
    return 1;
}
int log_cog_scan(const char *p,const char *t,log_cog_visitor visitor,void *context){
    document *d=load(p,t);
    if(!d)return -1;
    int result=0;
    for(size_t i=0;i<d->count;++i)if(visitor(d->rows[i].key,d->rows[i].value,
    context)){
        result=-1;
        break;
    }
    release(d);
    return result;
}
