#include "runtime_config.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wchar.h>

bool log_prepare_configuration(void) {
    wchar_t path[32768];
    DWORD count = GetModuleFileNameW(NULL, path, 32768);
    if (count == 0 || count >= 32768) {
        return false;
    }
    wchar_t *slash = wcsrchr(path, L'\\');
    if (slash == NULL) {
        return false;
    }
    *slash = L'\0';
    if (!SetCurrentDirectoryW(path)) {
        return false;
    }
    return GetFileAttributesW(L"pool.conf") != INVALID_FILE_ATTRIBUTES;
}
