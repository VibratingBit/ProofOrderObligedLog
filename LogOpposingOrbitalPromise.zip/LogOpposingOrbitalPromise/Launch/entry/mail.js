'use strict';
(() => {
  if (document.body.dataset.page !== 'mail') return;
  const $ = id => document.getElementById(id);
  let folder = 'inbox', selected = null, initialized = false, loading = false;
  async function api(path, fields) {
    if(location.protocol!=='https:') throw new Error('Open Mail over HTTPS.');
    const response = await fetch(path, fields ? {
      method:'POST', body:new URLSearchParams(fields),
      headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}
    } : {cache:'no-store'});
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || data.error || `HTTP ${response.status}`);
    return data;
  }
  async function list() {
    if (loading) return;
    loading = true;
    try {
      const messages = await api(`/api/mail?folder=${folder}`);
      $('mail-folder-title').textContent = folder[0].toUpperCase() + folder.slice(1);
      $('mail-list').replaceChildren(...messages.slice().reverse().map(message => {
        const button = document.createElement('button'); button.type = 'button';
        button.className = 'mail-row';
        const title = document.createElement('strong'); title.textContent = message.subject || '(No subject)';
        const envelope = document.createElement('span'); envelope.textContent = `${message.from} → ${message.to}`;
        const size = document.createElement('small'); size.textContent = `${message.size.toLocaleString()} bytes · ${message.delivery || "Stored"}`;
        button.append(title, envelope, size);
        button.addEventListener('click', async () => {
          try {
            const data = await api(`/api/mail?id=${message.id}`);
            selected = message;
            $('mail-retry').hidden=folder!=='outbox';
            $('mail-retry').disabled=message.delivery==='Sending…';
            $('mail-subject').textContent = message.subject || '(No subject)';
            $('mail-envelope').textContent = envelope.textContent;
            $('mail-source').textContent = data.text + (data.truncated ? '\n[Preview truncated at 128 KiB]' : '');
            $('mail-reader').showModal();
          } catch (error) { $('mail-status').textContent = String(error); }
        });
        return button;
      }));
      $('mail-status').textContent = messages.length ? `${messages.length} messages` : 'This folder is empty.';
      const blocked = await api('/api/mail/blocked');
      $('blocked-senders').replaceChildren(...blocked.map(address => {
        const li = document.createElement('li'); li.textContent = address; return li;
      }));
    } catch (error) { $('mail-status').textContent = String(error); }
    finally { loading = false; }
  }
  async function start() {
    if (initialized) return;
    if (window.poolSession?.role !== 3) {
      $('mail-status').textContent = 'Only owner Sshhm has an active mailbox.';
      document.querySelector('.mail-layout').hidden = true;
      return;
    }
    initialized = true;
    try {
      const status = await api('/api/mail/status');
      $('mail-from').replaceChildren(...status.addresses.map(address => {
        const option = document.createElement('option'); option.value = address;
        option.textContent = address; return option;
      }));
      $('mail-compose').disabled = !status.smtp;
      const preferred=status.addresses.find(address=>address.toLowerCase()==='sshhm@lovehive.org');
      if(preferred) $('mail-from').value=preferred;
      await list();
    } catch (error) { $('mail-status').textContent = String(error); }
  }
  for (const name of ['inbox','sent','archive','blocked','outbox']) {
    const button = document.createElement('button'); button.type = 'button';
    button.textContent = name[0].toUpperCase() + name.slice(1);
    button.addEventListener('click', () => { folder = name; list(); });
    $('mail-folders').append(button);
  }
  $('mail-delete').addEventListener('click',async () => {
    if(!selected || !confirm('Permanently delete this stored message?')) return;
    try {
      await api('/api/mail',{action:'delete',id:selected.id});
      $('mail-reader').close(); await list();
    }catch(error){$('mail-status').textContent=String(error);}
  });
  $('mail-retry').addEventListener('click',async () => {
    if(!selected || !confirm('Retry this delivery? If the destination accepted it before a connection failure, retrying can send a duplicate.')) return;
    try {
      const result=await api('/api/mail',{action:'retry',id:selected.id});
      $('mail-reader').close(); await list(); $('mail-status').textContent=result.message;
    }catch(error){$('mail-status').textContent=String(error);}
  });
  $('mail-reader-close').addEventListener('click', () => $('mail-reader').close());
  $('mail-compose').addEventListener('click', () => $('mail-composer').showModal());
  $('mail-compose-cancel').addEventListener('click', () => $('mail-composer').close());
  document.querySelectorAll('[data-mail-move]').forEach(button => {
    button.addEventListener('click', async () => {
      if (!selected) return;
      try {
        await api('/api/mail', {action:'move',id:selected.id,folder:button.dataset.mailMove});
        $('mail-reader').close(); await list();
      } catch (error) { $('mail-status').textContent = String(error); }
    });
  });
  $('block-message-sender').addEventListener('click', async () => {
    if (!selected) return;
    try {
      await api('/api/mail', {action:'block',address:selected.from});
      await api('/api/mail', {action:'move',id:selected.id,folder:'blocked'});
      $('mail-reader').close(); await list();
    } catch (error) { $('mail-status').textContent = String(error); }
  });
  $('mail-block-form').addEventListener('submit', async event => {
    event.preventDefault();
    const fields = new URLSearchParams(new FormData(event.currentTarget));
    fields.set('action',event.submitter.value);
    try { await api('/api/mail', fields); event.currentTarget.reset(); await list(); }
    catch (error) { $('mail-status').textContent = String(error); }
  });
  $('mail-send-form').addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget, submit = form.querySelector('button:not([type="button"])');
    const fields = new URLSearchParams(new FormData(form)); fields.set('action','send');
    submit.disabled = true; $('mail-send-status').textContent = 'Contacting destination mail server…';
    try {
      const result = await api('/api/mail', fields);
      form.reset(); $('mail-composer').close(); folder = result.queued ? 'outbox' : 'sent';
      await list(); $('mail-status').textContent = result.message;
    } catch (error) {
      $('mail-send-status').textContent = String(error);
      folder = 'outbox'; await list();
    } finally { submit.disabled = false; }
  });
  window.addEventListener('pool-session', start);
  setInterval(() => { if (initialized && !document.hidden) list(); }, 30000);
})();
