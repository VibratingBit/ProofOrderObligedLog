async function bootPool() {
  let status;
  try {
    const response=await fetch('/api/institute/status',{cache:'no-store'});
    if(!response.ok)throw new Error('Status unavailable');status=await response.json();
  }catch {document.body.textContent='Server status unavailable. Please reload.';return;}
  if(!status.live){
    const button=document.getElementById('begin-setup');
    const form=document.getElementById('setup-form');
    if(!button||!form){location.replace('/');return;}
    if(status.https===false) {
      button.disabled=true;
      document.getElementById('setup-status').textContent=
        'HTTP is online. HTTPS needs your certificate files: LoveShip-chain.pem and LoveShip-key.pem (project root or Launch/ssl). Configure pool.conf, then type restart in the server console.';
      return;
    }
    button.addEventListener('click',()=>{
      if(location.protocol!=='https:'){
        const secure=new URL('/',location.origin);secure.protocol='https:';secure.port='';
        location.assign(secure.href);return;
      }
      form.hidden=false;button.hidden=true;
    });
    form.addEventListener('submit',async event=>{
      event.preventDefault();
      if(location.protocol!=='https:')return;
      const message=document.getElementById('setup-status');
      if(form.elements.password.value!==form.elements.confirm.value){message.textContent='Passwords do not match.';return;}
      const submit=form.querySelector('button');submit.disabled=true;
      try {
        const response=await fetch('/api/institute/setup',{method:'POST',
          body:new URLSearchParams(new FormData(form))});
        const data=await response.json();if(!response.ok)throw new Error(data.error);
        form.reset();location.replace('/');
      }catch(error){message.textContent=String(error);}
      finally {submit.disabled=false;}
    });
    return;
  }
  if(status.https===false && ['institute','account','mail'].includes(document.body.dataset.page)) {
    document.body.textContent='HTTPS is offline. Configure your certificate and key in pool.conf, then restart the server. Account access requires HTTPS.';
    return;
  }
  if(document.body.dataset.page==='setup'){location.replace('/');return;}
  if(document.body.dataset.page==='mail' && location.protocol!=='https:') {
    const secure=new URL(location.href);secure.protocol='https:';secure.port='';
    location.replace(secure.href);return;
  }
'use strict';
const $ = id => document.getElementById(id);
let trafficBusy = false;
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;',
    '"': '&quot;', "'": '&#39;'
  }[character]));
}
function renderString(source, values) {
  return source.replace(/{{([a-zA-Z0-9_.]+)}}/g, (_, name) => {
    if (!Object.prototype.hasOwnProperty.call(values, name)) {
      throw new Error(`Unknown template value: ${name}`);
    }
    return escapeHTML(values[name]);
  });
}
function renderTemplate(id, values) {
  const source = document.getElementById(id);
  if (!(source instanceof HTMLTemplateElement)) {
    throw new Error(`Missing HTML template: ${id}`);
  }
  const fragment = source.content.cloneNode(true);
  fragment.querySelectorAll('[data-field]').forEach(element => {
    const name = element.dataset.field;
    if (!Object.prototype.hasOwnProperty.call(values, name)) {
      throw new Error(`Unknown template field: ${name}`);
    }
    element.textContent = String(values[name]);
  });
  return fragment;
}
window.PoolTemplates = Object.freeze({renderString, renderTemplate});
function facts(target, values) {
  if (!$(target)) return;
  $(target).replaceChildren(...values.map(([label, value]) =>
    renderTemplate('fact-template', {label, value})));
}
async function health() {
  const started = performance.now();
  try {
    const response = await fetch('/api/health', {cache: 'no-store'});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const latency = Math.round(performance.now() - started);
    facts('health-facts', [['Status', data.ok ? 'Online' : 'Unhealthy'],
      ['Engine', data.framework], ['Response', `${latency} ms`]]);
    if ($('health-detail')) $('health-detail').textContent = `GET /api/health · HTTP ${response.status}`;
    if ($('connection')) $('connection').textContent = `Connected · ${location.host}`;
    $('dot')?.classList.toggle('ok', Boolean(data.ok));
  } catch (error) {
    if ($('health-detail')) $('health-detail').textContent = String(error);
    if ($('connection')) $('connection').textContent = 'Server unavailable';
    $('dot')?.classList.remove('ok');
  }
}
async function traffic() {
  if (trafficBusy) return;
  trafficBusy = true;
  try {
    const response = await fetch('/api/metrics', {cache: 'no-store'});
    if (response.status === 403) {
      $('traffic-detail').textContent = 'Private metrics are available only from the server itself. Open this dashboard through 127.0.0.1.';
      return;
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    facts('traffic-facts', [['Requests', data.requests], ['Errors', data.errors],
      ['Sent', `${data.bytes_sent.toLocaleString()} B`],
      ['Uptime', `${data.uptime_seconds} s`]]);
    $('traffic-detail').textContent = 'In-memory totals, including dashboard requests. Reset on restart.';
  } catch (error) { $('traffic-detail').textContent = String(error); }
  finally { trafficBusy = false; }
}
document.querySelectorAll('.toggle').forEach(button => {
  button.addEventListener('click', () => {
    const card = button.closest('.card');
    const wasOpen = card.classList.contains('open');
    document.querySelectorAll('.card').forEach(item => {
      item.classList.remove('open'); item.querySelector('.panel').hidden = true;
      item.querySelector('.toggle').setAttribute('aria-expanded', 'false');
      item.querySelector('.plus').textContent = '+';
    });
    if (wasOpen) return;
    card.classList.add('open'); card.querySelector('.panel').hidden = false;
    button.setAttribute('aria-expanded', 'true');
    card.querySelector('.plus').textContent = '−';
    if (card.dataset.card === 'health') health();
    if (card.dataset.card === 'traffic') traffic();
  });
});
async function responses() {
  $('test-responses').disabled = true;
  $('responses').replaceChildren();
  const tests = [
    ['GET', '/api/health', 200], ['GET', '/favicon.ico', 200],
    ['GET', '/not-a-real-route', 404], ['POST', '/api/echo', 200]
  ];
  for (const [method, path, expected] of tests) {
    let result;
    try {
      const response = await fetch(path, {method, cache: 'no-store',
        ...(method === 'POST' ? {body: 'Tarjeta response test'} : {})});
      const body = await response.text();
      let valid = response.status === expected;
      if (path === '/api/echo') valid = valid && body === 'Tarjeta response test';
      result = `${valid ? 'PASS' : 'FAIL'} · HTTP ${response.status}`;
    } catch (error) { result = `FAIL · ${error}`; }
    const row = document.createElement('tr');
    for (const value of [`${method} ${path}`, expected, result]) {
      const cell = document.createElement('td'); cell.textContent = value;
      row.append(cell);
    }
    $('responses').append(row);
  }
  $('test-responses').disabled = false;
}
$('refresh-health')?.addEventListener('click', health);
$('test-responses')?.addEventListener('click', responses);
if ($('origin')) $('origin').textContent = `Current origin: ${location.origin}`;
setInterval(() => {
  if (!document.hidden && document.querySelector('[data-card="traffic"].open')) traffic();
}, 2000);
if ($('connection')) health();

// Data drives navigation, selectors and account notices through HTML templates.
const themes = [
  ['slate', 'Dark gray', '#272c30', '#34393d', '#34393d', '#555f68', '#e6e8eb', '#b7bcc1', 'dark'],
  ['black', 'Black', '#090a0c', '#111317', '#16191e', '#41454c', '#f0f0f2', '#aeb3bd', 'dark'],
  ['midnight', 'Midnight', '#111827', '#192339', '#1e2b42', '#425270', '#e4ecfc', '#a8b6d0', 'dark'],
  ['forest', 'Forest', '#15221b', '#203328', '#243a2c', '#4a6651', '#e4eee3', '#afc4af', 'dark'],
  ['ocean', 'Ocean', '#10242c', '#19343e', '#21404a', '#476b77', '#dfedf1', '#a5c0c9', 'dark'],
  ['twilight', 'Twilight', '#221c30', '#32293e', '#3b3048', '#675773', '#eee3f5', '#bfb0cf', 'dark'],
  ['sunset', 'Sunset', '#2a1e1c', '#3c2b29', '#44312e', '#76594e', '#f5e8de', '#cbb5a6', 'dark'],
  ['lavender', 'Lavender', '#e8e4f2', '#f4f0fa', '#faf7ff', '#b1a5c7', '#322b43', '#655b74', 'light'],
  ['ivory', 'Ivory', '#eee9dd', '#f8f4e9', '#fffaf0', '#b9ae95', '#353124', '#6b624c', 'light'],
  ['cloud', 'Cloud', '#e7ebef', '#f3f6f8', '#ffffff', '#adb8c3', '#25303a', '#566574', 'light'],
  ['rose', 'Rosewater', '#f0e2e5', '#faeef0', '#fff6f7', '#c5a7b0', '#492d37', '#795965', 'light'],
  ['sage', 'Sage', '#e2e9df', '#f0f5ec', '#f8fcf5', '#a7b7a0', '#293b29', '#5a6e54', 'light']
];
const accents = [
  ['ice', 'Ice', '#b7e6f4'], ['turquoise', 'Turquoise', '#55d8c5'],
  ['blue', 'Blue', '#79b5ff'], ['green', 'Green', '#82d59b'],
  ['violet', 'Violet', '#b69af7'], ['pink', 'Pink', '#f19bc3'],
  ['orange', 'Orange', '#f8b078'], ['gold', 'Gold', '#e8ca78'],
  ['crimson', 'Crimson', '#f18394'], ['lime', 'Lime', '#c6e57d'],
  ['coral', 'Coral', '#f3a091'], ['silver', 'Silver', '#c8d0d9'],
  ['copper', 'Copper', '#ce9c7d'], ['white', 'White', '#ffffff'],
  ['black', 'Black', '#16191e'], ['mint', 'Soft mint', '#a9e3ce'],
  ['periwinkle', 'Periwinkle', '#b0bbfa'], ['peach', 'Peach', '#f0c3a0']
];
function populateSelect(id, entries) {
  $(id).replaceChildren(...entries.map(([value, label]) => {
    const fragment = renderTemplate('option-template', {label});
    fragment.querySelector('option').value = value;
    return fragment;
  }));
}
function savedPreference(name, fallback) {
  try { return localStorage.getItem(`pool.${name}`) || fallback; }
  catch { return fallback; }
}
const textSizes = Array.from({length: 13}, (_, index) =>
  [String(index + 8), `${index + 8} px`]);
function applyTextSize() {
  const value = Number($('text-size-select').value);
  const size = Number.isInteger(value) && value >= 8 && value <= 20 ? value : 13;
  document.documentElement.style.setProperty('--text-size', `${size}px`);
  try { localStorage.setItem('pool.textSize', String(size)); } catch {}
}
function applyAppearance() {
  const theme = themes.find(item => item[0] === $('theme-select').value) || themes[0];
  const accent = accents.find(item => item[0] === $('accent-select').value) || accents[0];
  const keys = ['bg', 'header', 'surface', 'border', 'ink', 'muted'];
  keys.forEach((key, index) => {
    document.documentElement.style.setProperty(`--${key}`, theme[index + 2]);
  });
  document.documentElement.style.colorScheme = theme[8];
  document.documentElement.style.setProperty('--accent', accent[2]);
  try {
    localStorage.setItem('pool.theme', theme[0]);
    localStorage.setItem('pool.accent', accent[0]);
  } catch { /* Appearance still works when storage is unavailable. */ }
}
populateSelect('theme-select', themes);
populateSelect('accent-select', accents);
populateSelect('text-size-select', textSizes);
const storedSize=savedPreference('textSize','13');
$('text-size-select').value=textSizes.some(item=>item[0]===storedSize)?storedSize:'13';
$('text-size-select').addEventListener('change',applyTextSize);
applyTextSize();
const storedTheme = savedPreference('theme', 'slate');
const storedAccent = savedPreference('accent', 'ice');
$('theme-select').value = themes.some(item => item[0] === storedTheme) ? storedTheme : 'slate';
$('accent-select').value = accents.some(item => item[0] === storedAccent) ? storedAccent : 'ice';
$('theme-select').addEventListener('change', applyAppearance);
$('accent-select').addEventListener('change', applyAppearance);
applyAppearance();
function returnPath() {
  let path=new URLSearchParams(location.search).get('returnTo') || '/';
  try { path=new URLSearchParams(location.search).get('returnTo') ||
    sessionStorage.getItem('pool.returnTo') || '/'; } catch {}
  return /^\/(?:[A-Za-z0-9_-]{1,40})?$/.test(path) &&
    !/^\/(Institute|account|acccount)$/i.test(path) ? path : '/';
}
async function logout() {
  await fetch('/api/institute/logout',{method:'POST',
    headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
  location.assign('/');
}
function renderNavigation() {
  const signedIn=Boolean(window.poolSession);
  const navigation=signedIn
    ? [{label:'Landing',action:'landing'},{label:'Logout',action:'logout'}]
    : [{label:'Landing',action:'landing'},{label:'Login',action:'login'},
       {label:'Register',action:'register'}];
  $('main-nav').replaceChildren(...navigation.map(item=>{
    const fragment=renderTemplate('nav-item-template',item);
    const button=fragment.querySelector('button');
    button.disabled=status.https===false && ['login','register'].includes(item.action);
    button.addEventListener('click',()=>{
      if(item.action==='landing'){location.assign('/');return;}
      if(item.action==='logout'){logout();return;}
      const target=new URL('/Institute',location.origin);
      target.protocol='https:';
      if(location.protocol!=='https:')target.port='';
      target.searchParams.set('mode',item.action);
      const back=/^\/(?:[A-Za-z0-9_-]{1,40})?$/.test(location.pathname) &&
        !/^\/(Institute|account|acccount)$/i.test(location.pathname)
        ? location.pathname : returnPath();
      target.searchParams.set('returnTo',back);
      location.assign(target.href);
    });
    return fragment;
  }));
  if($('current-domain')) {
    $('current-domain').textContent=signedIn?window.poolSession.username:location.hostname;
    $('current-domain').href=signedIn?'/acccount':location.origin;
  }
}
const asciiArt={book:' .----.\n/BOOK/|\n|___|/',
  canvas:'+-----+\n| /\\ *|\n|_____ |',rabbit:'(\\_/)\n(o.o)\n/> <\\',star:'  *\n *+*\n  *'};
renderNavigation();
if(!/^\/(Institute|account|acccount)\/?$/i.test(location.pathname)) {
  try {sessionStorage.setItem('pool.returnTo',location.pathname);}catch{}
}

// Canvas cards: browser-local drafts. No role or publication claim is stored here.
if ($('workspace-content')) {
  const pageRoute = location.pathname === '/' || location.pathname === '/index.html' ? 'Landing' : location.pathname.replace(/^\/|\/$/g, '');
  const storageKey = `pool.canvasDrafts.v2.${pageRoute}`;
  let pageMeta = {heading: '', description: '', content: '', ascii: 'book'};
  let cards = [];
  let editing = null;
  const editor = $('card-editor');
  const form = $('card-form');
  function validCard(card) {
    return card && typeof card.id === 'string' && card.id.length <= 100 &&
      (card.category === undefined || (typeof card.category === 'string' && card.category.length <= 80)) &&
      typeof card.heading === 'string' && card.heading.length <= 120 &&
      typeof card.description === 'string' && card.description.length <= 280 &&
      typeof card.content === 'string' && card.content.length <= 10000;
  }
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) || '[]');
    if (Array.isArray(stored)) cards = stored.filter(validCard).slice(0, 100);
  } catch { /* A blocked or corrupt store must not stop the rest of the page. */ }
  function drawCards() {
    $('workspace-content').replaceChildren(...cards.map((card, index) => {
      const fragment = renderTemplate('workspace-card-template', {
        ascii: asciiArt[card.ascii] || asciiArt.book,
        number: card.category || `${String(index + 1).padStart(2, '0')}`, 
        heading: card.heading, description: card.description, content: card.content
      });
      const article = fragment.querySelector('article');
      article.dataset.id = card.id;
      const content = article.querySelector('.canvas-content');
      content.replaceChildren(renderBBCode(card.content));
      if(typeof card.details==='string') {
        const group=document.createElement('div');group.className='facts';
        for(const line of card.details.split('\n').slice(0,20)) {
          const split=line.indexOf('|');if(split<0)continue;
          group.append(renderTemplate('fact-template',{
            label:line.slice(0,split).trim(),value:line.slice(split+1).trim()}));
        }
        content.append(group);
      }
      if(typeof card.actionUrl==='string'&&typeof card.actionLabel==='string') {
        const href=safeMediaURL(card.actionUrl);
        if(href){const link=document.createElement('a');link.href=href;
          link.className='card-action';link.textContent=card.actionLabel;content.append(link);}
      }
      article.querySelector('.card-tools').hidden = !(window.poolSession?.role >= 2);
      const panel = article.querySelector('.panel');
      panel.id = `draft-panel-${index}`;
      article.querySelector('.toggle').setAttribute('aria-controls', panel.id);
      return fragment;
    }));
  }
  function openEditor(card = null) {
    editing = card ? card.id : null;
    $('card-editor-title').textContent = card ? 'Edit canvas card' : 'Create canvas card';
    form.elements.ascii.value = card?.ascii || 'book';
    form.elements.details.value = card?.details || '';
    form.elements.actionLabel.value = card?.actionLabel || '';
    form.elements.actionUrl.value = card?.actionUrl || '';
    form.elements.category.value = card?.category || '';
    form.elements.heading.value = card?.heading || '';
    form.elements.description.value = card?.description || '';
    form.elements.content.value = card?.content || '';
    $('card-error').textContent = '';
    editor.showModal();
    form.querySelectorAll('textarea').forEach(growArea);
    form.elements.heading.focus();
  }
  function persist(next) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(next));
      cards = next;
      drawCards();
      return true;
    } catch {
      $('card-error').textContent = 'Storage is unavailable or full. Copy your draft before closing.';
      return false;
    }
  }
  $('create-card').hidden = true;
  $('create-card').addEventListener('click', () => openEditor());
  $('cancel-card').addEventListener('click', () => editor.close());
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const card = {
      id: editing || (globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`),
      ascii: form.elements.ascii.value, details:form.elements.details.value,
      actionLabel:form.elements.actionLabel.value, actionUrl:form.elements.actionUrl.value,
      category: form.elements.category.value.trim(),
      heading: form.elements.heading.value.trim(),
      description: form.elements.description.value.trim(),
      content: form.elements.content.value.trim()
    };
    if (!card.heading || !card.content || !validCard(card)) return;
    if (!editing && cards.length >= 100) {
      $('card-error').textContent = 'Limit reached: 100 browser drafts.';
      return;
    }
    const next = editing ? cards.map(item => item.id === editing ? card : item) : [...cards, card];
    if (persist(next)) editor.close();
  });
  $('workspace-content').addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const article = button.closest('.canvas-card');
    const card = cards.find(item => item.id === article.dataset.id);
    if (!card) return;
    if (button.dataset.action !== 'toggle' && !(window.poolSession?.role >= 2)) return;
    if (button.dataset.action === 'edit') { openEditor(card); return; }
    if (button.dataset.action === 'delete') {
      if (confirm(`Delete card “${card.heading}”?`)) {
        if (!persist(cards.filter(item => item.id !== card.id))) {
          alert('Could not save deletion. Your draft has been kept.');
        }
      }
      return;
    }
    const wasOpen = article.classList.contains('open');
    $('workspace-content').querySelectorAll('.canvas-card').forEach(item => {
      item.classList.remove('open');
      item.querySelector('.panel').hidden = true;
      item.querySelector('.toggle').setAttribute('aria-expanded', 'false');
      item.querySelector('.plus').textContent = '+';
    });
    if (!wasOpen) {
      article.classList.add('open');
      article.querySelector('.panel').hidden = false;
      button.setAttribute('aria-expanded', 'true');
      article.querySelector('.plus').textContent = '−';
    }
  });
  function applyPermissions() {
    const canEdit = window.poolSession?.role >= 2;
    $('create-card').hidden = !canEdit;
    $('publish-cards').hidden = !canEdit;
    drawCards();
  }
  window.addEventListener('pool-session', applyPermissions);
  $('publish-cards').addEventListener('click', async () => {
    const body = new URLSearchParams({action: 'save', route: pageRoute,
      heading: pageMeta.heading, description: pageMeta.description,
      content: pageMeta.content, ascii:pageMeta.ascii, cards: JSON.stringify(cards)});
    try {
      const response = await fetch('/api/pages', {method:'POST', body,
        headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      window.poolPublishedCards=JSON.stringify(cards);
      alert('Workspace published.');
    } catch (error) { alert(String(error)); }
  });
  fetch(`/api/pages?route=${encodeURIComponent(pageRoute)}`, {cache:'no-store'})
    .then(async response => {
      if (!response.ok) return;
      const page = new URLSearchParams(await response.text());
      pageMeta = {heading:page.get('heading') || '',
        description:page.get('description') || '',content:page.get('content') || '',
        ascii:page.get('ascii') || 'book'};
      if($('trail-art')) $('trail-art').textContent=asciiArt[pageMeta.ascii] || asciiArt.book;
      window.poolPageMetadata = {...pageMeta, route:pageRoute};
      if (pageMeta.heading) document.querySelector('h1').textContent = pageMeta.heading;
      const intro = document.querySelector('.intro-copy > p:not(.eyebrow)');
      if (intro && pageMeta.description) intro.textContent = pageMeta.description;
      if (pageMeta.content) {
        const text = document.createElement('div'); text.className='page-text';
        text.append(renderBBCode(pageMeta.content));
        document.querySelector('.workspace-shell').before(text);
      }
      const published = JSON.parse(page.get('cards') || '[]');
      if (Array.isArray(published)) cards=published.filter(validCard).slice(0,100);
      window.poolPublishedCards = JSON.stringify(cards);
      applyPermissions();
    }).catch(() => {});
  applyPermissions();
}

function safeMediaURL(value) {
  const trimmed = value.trim();
  if (!trimmed || /[\u0000-\u001f]/.test(trimmed)) return null;
  try {
    const url = new URL(trimmed, location.href);
    return ['http:', 'https:'].includes(url.protocol) ? url.href : null;
  } catch { return null; }
}
function renderBBCode(value) {
  const fragment = document.createDocumentFragment();
  const text = String(value).replace(/\[\\(img|video|audio|b|i|u|url|code|quote)\]/gi, '[/$1]');
  const pattern = /\[(img|video|audio|b|i|u|url|code|quote)\]([\s\S]*?)\[\/\1\]/gi;
  let previous = 0, count = 0, match;
  while ((match = pattern.exec(text)) && count++ < 50) {
    fragment.append(document.createTextNode(text.slice(previous, match.index)));
    const tag = match[1].toLowerCase();
    const body = match[2];
    if(tag==='code'||tag==='quote') {
      const node=document.createElement(tag==='code'?'pre':'blockquote');
      node.className=tag==='code'?'bb-code':'bb-quote';node.textContent=body;
      fragment.append(node);
    } else if (['b', 'i', 'u'].includes(tag)) {
      const node = document.createElement({b:'strong',i:'em',u:'u'}[tag]);
      node.textContent = body; fragment.append(node);
    } else {
      const url = safeMediaURL(body);
      if (!url) fragment.append(document.createTextNode(match[0]));
      else if (tag === 'url') {
        const link = document.createElement('a'); link.href = url;
        link.rel = 'noopener noreferrer'; link.textContent = body.trim();
        fragment.append(link);
      } else {
        const frame = document.createElement('span'); frame.className = 'media-frame';
        const media = document.createElement(tag === 'img' ? 'img' : tag);
        media.src = url;
        if (tag === 'img') { media.alt = 'Card image'; media.loading = 'lazy'; }
        else { media.controls = true; media.preload = 'metadata'; }
        const expand = document.createElement('button');
        expand.type = 'button'; expand.className = 'expand-media';
        expand.textContent = 'Enlarge';
        expand.addEventListener('click', () => {
          if (!$('media-viewer')) return;
          const preview = media.cloneNode(true);
          $('media-content').replaceChildren(preview);
          $('media-viewer').showModal();
        });
        if (tag === 'img') media.addEventListener('click', () => expand.click());
        const name=document.createElement('span');name.className='media-name';
        try { name.textContent=decodeURIComponent(new URL(url).pathname.split('/').pop()) || 'Media'; }
        catch { name.textContent='Media'; }
        frame.append(media,name,expand); fragment.append(frame);
      }
    }
    previous = pattern.lastIndex;
  }
  fragment.append(document.createTextNode(text.slice(previous)));
  return fragment;
}
$('close-media')?.addEventListener('click', () => $('media-viewer').close());
$('media-viewer')?.addEventListener('close', () => $('media-content').replaceChildren());
if ($('current-domain')) {
  $('current-domain').textContent = location.hostname;
  $('current-domain').href = location.origin;
}
async function loadRoutes() {
  try {
    const response = await fetch('/api/routes', {cache:'no-store'});
    if (!response.ok) return;
    const routes = await response.json();
    routes.sort((a,b) => a.label.localeCompare(b.label, undefined, {sensitivity:'base'}));
    $('route-bar').replaceChildren(...routes.filter(item =>
      /^\/[A-Za-z0-9_-]{1,40}$/.test(item.path) && item.path!=='/Media').map(item => {
      const fragment = renderTemplate('route-item-template', {label:item.label});
      fragment.querySelector('a').href = item.path;
      return fragment;
    }));
  } catch { /* Service status is reported separately. */ }
}
window.poolSession = null;
async function refreshSession() {
  try {
    const response = await fetch('/api/institute/session', {cache:'no-store'});
    window.poolSession = response.ok ? await response.json() : null;
  } catch { window.poolSession = null; }
  const privileged = window.poolSession?.role >= 2;
  if ($('edit-page')) $('edit-page').hidden = !privileged;
  if ($('create-page')) $('create-page').hidden = !privileged;
  renderNavigation();
  loadRoutes();
  if(document.body.dataset.page==='institute') {
    if(window.poolSession){location.replace(returnPath());return;}
    document.body.removeAttribute('data-auth-pending');
  }
  if(['account','mail'].includes(document.body.dataset.page)) {
    if(!window.poolSession){location.replace('/Institute');return;}
    if($('account-status')) $('account-status').textContent=`${window.poolSession.username} · Account management`;
  }
  window.dispatchEvent(new Event('pool-session'));
  if ($('institute-status')) {
    $('institute-status').textContent = window.poolSession
      ? `Signed in as ${window.poolSession.username}. Role: ${window.poolSession.role === 3 ? 'administrator' : window.poolSession.role === 2 ? 'moderator' : 'member'}.`
      : location.protocol !== 'https:' ? 'Open this page over HTTPS to register or sign in.' : 'Not signed in.';
    if($('institute-logout')) $('institute-logout').hidden = !window.poolSession;
  }
}
$('institute-logout')?.addEventListener('click', async () => {
  await fetch('/api/institute/logout', {method:'POST',
    headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
  await refreshSession();
});
$('create-page')?.addEventListener('click', () => {
  if (!$('page-editor')) { location.assign('/'); return; }
  $('page-form').reset(); $('page-form').dataset.action = 'create';
  $('page-form').elements.route.readOnly = false;
  $('page-error').textContent = '';
  $('page-editor').showModal();
  $('page-form').querySelectorAll('textarea').forEach(growArea);
});
$('cancel-page')?.addEventListener('click', () => $('page-editor').close());
$('page-form')?.addEventListener('submit', async event => {
  event.preventDefault();
  const body = new URLSearchParams(new FormData(event.currentTarget));
  body.set('action', event.currentTarget.dataset.action || 'create');
  body.set('cards', event.currentTarget.dataset.action === 'save'
    ? window.poolPublishedCards || '[]' : '[]');
  try {
    const response = await fetch('/api/pages', {method:'POST',body,
      headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error);
    location.assign(`/${encodeURIComponent(body.get('route'))}`);
  } catch (error) { $('page-error').textContent = String(error); }
});
loadRoutes(); refreshSession();
window.poolReady=true;
window.dispatchEvent(new Event('pool-ready'));
function growArea(area) {
  const baseline=Number(area.dataset.baseline)||Math.max(120,area.rows*20);
  area.dataset.baseline=String(baseline);area.style.height='auto';
  area.style.height=`${Math.max(baseline,Math.min(area.scrollHeight,baseline*2))}px`;
}
document.querySelectorAll('textarea').forEach(area=>{
  area.addEventListener('input',()=>growArea(area));
});

$('edit-page')?.addEventListener('click', () => {
  const data = window.poolPageMetadata || {
    route:'Landing',heading:document.querySelector('h1').textContent,
    description:'',content:''
  };
  const form = $('page-form');
  for (const key of ['route','heading','description','content','ascii']) {
    form.elements[key].value = data[key] || (key==='ascii'?'book':'');
  }
  form.elements.route.readOnly = true;
  form.dataset.action = 'save';
  $('page-error').textContent = '';
  $('page-editor').showModal();
  $('page-form').querySelectorAll('textarea').forEach(growArea);
});

window.addEventListener('pool-session', async () => {
  if (!$('member-management')) return;
  $('member-management').hidden = window.poolSession?.role !== 3;
  if (window.poolSession?.role !== 3) return;
  try {
    const response = await fetch('/api/institute/members', {cache:'no-store'});
    if (!response.ok) return;
    const members = await response.json();
    $('member-list').replaceChildren(...members.filter(member => member.role !== 3).map(member => {
      const option = document.createElement('option');
      option.value = member.username; option.textContent = member.username;
      return option;
    }));
  } catch {}
});
$('member-management')?.addEventListener('submit', async event => {
  event.preventDefault();
  const action = event.submitter?.value;
  if (action === 'delete' && !confirm('Remove this member permanently?')) return;
  const body = new URLSearchParams(new FormData(event.currentTarget));
  body.set('action', action);
  try {
    const response = await fetch('/api/institute/members', {method:'POST',body,
      headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error);
    await refreshSession();
    $('account-status').textContent = result.message;
    location.assign('/Institute');
  } catch (error) { $('institute-status').textContent = String(error); }
});

window.addEventListener('focus', loadRoutes);
setInterval(() => { if (!document.hidden) loadRoutes(); }, 10000);

for(const action of ['login','register']) {
  $(`${action}-form`)?.addEventListener('submit',async event=>{
    event.preventDefault();
    if(location.protocol!=='https:'){
      $('institute-status').textContent='Use HTTPS to sign in.';return;
    }
    const form=event.currentTarget;
    if(action==='register'&&form.elements.password.value!==form.elements.confirm.value){
      $('institute-status').textContent='Passwords do not match.';return;
    }
    const button=form.querySelector('button');button.disabled=true;
    try {
      const response=await fetch(`/api/institute/${action}`,{
        method:'POST',body:new URLSearchParams(new FormData(form))});
      const result=await response.json();if(!response.ok)throw new Error(result.error);
      form.reset();location.replace(returnPath());
    } catch(error){$('institute-status').textContent=String(error);}
    finally {button.disabled=false;}
  });
}
$('password-form')?.addEventListener('submit',async event=>{
  event.preventDefault();
  const form=event.currentTarget;
  try {
    const response=await fetch('/api/institute/password',{method:'POST',
      body:new URLSearchParams(new FormData(form)),
      headers:{'X-CSRF-Token':window.poolSession?.csrf || ''}});
    const result=await response.json();if(!response.ok)throw new Error(result.error);
    form.reset();location.assign('/Institute');
  }catch(error){$('password-status').textContent=String(error);}
});
if($('bbcode-tools')) {
  const tools=[['B','b'],['I','i'],['Underline','u'],['Code','code'],
    ['Quote','quote'],['Image','img'],['Video','video'],['Link','url'],
    ['☺','☺'],['♥','♥'],['★','★']];
  for(const [label,tag] of tools){
    const button=document.createElement('button');button.type='button';button.textContent=label;
    button.addEventListener('click',()=>{
      const area=$('card-form').elements.content;
      const selection=area.value.slice(area.selectionStart,area.selectionEnd);
      const text=tag.length>1?`[${tag}]${selection}[/${tag}]`:tag;
      // Single-letter formatting tags also wrap selections.
      const insert=['b','i','u'].includes(tag)?`[${tag}]${selection}[/${tag}]`:text;
      area.setRangeText(insert,area.selectionStart,area.selectionEnd,'end');
      area.focus();growArea(area);
    });
    $('bbcode-tools').append(button);
  }
}

}
bootPool();
